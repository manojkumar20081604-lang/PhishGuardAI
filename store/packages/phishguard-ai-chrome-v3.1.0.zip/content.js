function h(e){return new Promise((a,i)=>{chrome.runtime.sendMessage({action:"analyze",url:e},n=>{if(chrome.runtime.lastError){i(new Error(chrome.runtime.lastError.message));return}n&&n.success&&n.data?a(n.data):i(new Error((n==null?void 0:n.error)||"Analysis failed"))})})}function p(e){const a=Number(e.risk_score??0),i=String(e.prediction??"safe").toLowerCase(),n=i==="phishing"?"Phishing":i==="suspicious"?"Suspicious":"Safe",o=i==="phishing"?"High":i==="suspicious"?"Medium":"Low",r=Number(e.confidence??0);return{finalPrediction:n,finalConfidence:r>1?Math.round(r):Math.round(r*100),finalRiskScore:a,finalThreatLevel:o,sources:{local:!1,backend:!0,threatIntel:!1},explanation:{summary:e.summary||"",riskIndicators:Array.isArray(e.reasons)?e.reasons:[],recommendations:Array.isArray(e.security_tips)?e.security_tips:[],breakdown:{backendScore:a}},analyzedAt:e.analyzed_at||new Date().toISOString(),isCached:!!e.isCached}}chrome.runtime.onMessage.addListener((e,a,i)=>{switch(e.action){case"showAnalysis":d(e.data),i({success:!0});break;case"showWarning":y(e.data),i({success:!0});break;case"injectUI":g(e.data),i({success:!0});break;case"getPageInfo":i(x());break;case"analyzePage":return C().then(n=>i(n)),!0}return!0});function x(){var e,a;return{url:window.location.href,title:document.title,domain:window.location.hostname,forms:k(),links:w(),scripts:S(),iframes:L(),meta:I(),textContent:((a=(e=document.body)==null?void 0:e.innerText)==null?void 0:a.substring(0,5e3))||""}}function k(){return Array.from(document.forms).map(a=>({action:a.action,method:a.method,inputs:Array.from(a.elements).map(i=>({type:i.type,name:i.name,id:i.id,value:i.type==="password"?"[REDACTED]":i.value}))}))}function w(){return Array.from(document.querySelectorAll("a[href]")).slice(0,50).map(a=>{var i;return{href:a.href,text:(i=a.textContent)==null?void 0:i.trim().substring(0,100),target:a.target,rel:a.rel}})}function S(){return Array.from(document.querySelectorAll("script[src]")).map(a=>({src:a.src,async:a.async,defer:a.defer}))}function L(){return Array.from(document.querySelectorAll("iframe[src]")).map(a=>({src:a.src,width:a.width,height:a.height}))}function I(){const e=Array.from(document.querySelectorAll("meta")),a={};return e.forEach(i=>{i.name&&(a[i.name]=i.content);const n=i.getAttribute("property");n&&(a[n]=i.content)}),a}async function C(){const e=x(),a=e.forms.some(i=>i.inputs.some(n=>n.type==="password")||i.inputs.some(n=>/user|email|login|signin/i.test(n.name||"")));try{const i=p(await h(e.url)),n=[...i.explanation.riskIndicators,...a?["Login form detected on page"]:[]];return a&&!n.includes("Login form detected on page")&&n.push("Login form detected on page"),{...i,explanation:{...i.explanation,riskIndicators:n,recommendations:a&&i.finalThreatLevel!=="Low"?["DO NOT enter credentials on this page",...i.explanation.recommendations]:i.explanation.recommendations},pageInfo:{hasLoginForm:a,formsCount:e.forms.length,linksCount:e.links.length,scriptsCount:e.scripts.length,iframesCount:e.iframes.length}}}catch(i){return{finalPrediction:"Unknown",finalConfidence:0,finalRiskScore:0,finalThreatLevel:"Unknown",sources:{local:!0,backend:!1,threatIntel:!1},explanation:{summary:"Backend unavailable - only basic page checks were performed.",riskIndicators:[...a?["Login form detected on page"]:[]],recommendations:["Verify the site authenticity before entering sensitive data"],breakdown:{}},analyzedAt:new Date().toISOString(),error:i instanceof Error?i.message:String(i),pageInfo:{hasLoginForm:a,formsCount:e.forms.length,linksCount:e.links.length,scriptsCount:e.scripts.length,iframesCount:e.iframes.length}}}}function g(e){if(document.getElementById("phishguard-float-btn"))return;const a=document.createElement("div");a.id="phishguard-float-btn",a.innerHTML=`
    <style>
      #phishguard-float-btn {
        position: fixed;
        bottom: 20px;
        right: 20px;
        width: 56px;
        height: 56px;
        border-radius: 28px;
        background: linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%);
        box-shadow: 0 4px 20px rgba(30, 58, 138, 0.4);
        cursor: pointer;
        z-index: 2147483647;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: transform 0.2s, box-shadow 0.2s;
        border: none;
      }
      #phishguard-float-btn:hover {
        transform: scale(1.1);
        box-shadow: 0 6px 28px rgba(30, 58, 138, 0.5);
      }
      #phishguard-float-btn.phishguard-safe { background: linear-gradient(135deg, #065f46 0%, #10b981 100%); }
      #phishguard-float-btn.phishguard-suspicious { background: linear-gradient(135deg, #92400e 0%, #f59e0b 100%); }
      #phishguard-float-btn.phishguard-phishing { background: linear-gradient(135deg, #991b1b 0%, #ef4444 100%); animation: phishguard-pulse 2s infinite; }
      @keyframes phishguard-pulse { 0%, 100% { box-shadow: 0 4px 20px rgba(239, 68, 68, 0.4); } 50% { box-shadow: 0 4px 30px rgba(239, 68, 68, 0.7); } }
      #phishguard-float-btn svg { width: 28px; height: 28px; color: white; }
      #phishguard-tooltip {
        position: absolute;
        bottom: 70px;
        right: 0;
        background: #1e293b;
        color: white;
        padding: 8px 12px;
        border-radius: 6px;
        font-size: 12px;
        white-space: nowrap;
        opacity: 0;
        visibility: hidden;
        transition: opacity 0.2s, visibility 0.2s;
        pointer-events: none;
      }
      #phishguard-float-btn:hover #phishguard-tooltip {
        opacity: 1;
        visibility: visible;
      }
    </style>
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path>
      <path d="M9 12l2 2 4-4"></path>
    </svg>
    <div id="phishguard-tooltip">PhishGuard AI - Click to analyze</div>
  `,e?t(a,e.finalThreatLevel):(t(a,"Low"),h(window.location.href).then(i=>{document.getElementById("phishguard-float-btn")&&t(a,p(i).finalThreatLevel)}).catch(()=>{})),a.addEventListener("click",()=>{chrome.runtime.sendMessage({action:"analyze",url:window.location.href},i=>{chrome.runtime.lastError||!i||!i.success||(d(i.data),t(a,i.data.finalThreatLevel))})}),document.body.appendChild(a)}function t(e,a){switch(e.className="phishguard-float-btn",a){case"High":e.classList.add("phishguard-phishing"),e.querySelector("#phishguard-tooltip").textContent="⚠ Phishing detected - Click for details";break;case"Medium":e.classList.add("phishguard-suspicious"),e.querySelector("#phishguard-tooltip").textContent="⚠ Suspicious - Click for details";break;case"Low":default:e.classList.add("phishguard-safe"),e.querySelector("#phishguard-tooltip").textContent="✓ Safe - Click to re-analyze";break}}function d(e){var o;const a=document.getElementById("phishguard-modal");a&&a.remove();const i=document.createElement("div");i.id="phishguard-modal",i.innerHTML=`
    <style>
      #phishguard-modal-overlay {
        position: fixed;
        top: 0; left: 0; right: 0; bottom: 0;
        background: rgba(0, 0, 0, 0.7);
        z-index: 2147483646;
        display: flex;
        align-items: center;
        justify-content: center;
        animation: phishguard-fade-in 0.2s ease;
      }
      @keyframes phishguard-fade-in { from { opacity: 0; } to { opacity: 1; } }
      #phishguard-modal {
        background: #1e293b;
        border-radius: 16px;
        padding: 0;
        max-width: 520px;
        width: 90%;
        max-height: 85vh;
        overflow: hidden;
        box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
        border: 1px solid #334155;
        animation: phishguard-slide-up 0.3s ease;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      }
      @keyframes phishguard-slide-up { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
      .phishguard-header {
        padding: 20px 24px;
        border-bottom: 1px solid #334155;
        display: flex;
        align-items: center;
        justify-content: space-between;
      }
      .phishguard-header h2 { margin: 0; font-size: 18px; font-weight: 600; color: #f1f5f9; }
      .phishguard-badge {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 6px 14px;
        border-radius: 20px;
        font-size: 13px;
        font-weight: 600;
      }
      .phishguard-badge.phishing { background: rgba(239, 68, 68, 0.2); color: #ef4444; }
      .phishguard-badge.suspicious { background: rgba(245, 158, 11, 0.2); color: #f59e0b; }
      .phishguard-badge.safe { background: rgba(16, 185, 129, 0.2); color: #10b981; }
      .phishguard-close {
        background: none;
        border: none;
        color: #94a3b8;
        cursor: pointer;
        padding: 8px;
        border-radius: 8px;
        transition: background 0.2s, color 0.2s;
      }
      .phishguard-close:hover { background: #334155; color: #f1f5f9; }
      .phishguard-content { padding: 24px; overflow-y: auto; max-height: 60vh; }
      .phishguard-section { margin-bottom: 24px; }
      .phishguard-section:last-child { margin-bottom: 0; }
      .phishguard-section-title { font-size: 14px; font-weight: 600; color: #94a3b8; text-transform: uppercase; letter-spacing: 0.05em; margin-bottom: 12px; }
      .phishguard-score { display: flex; align-items: center; gap: 16px; }
      .phishguard-score-circle {
        width: 80px;
        height: 80px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        position: relative;
      }
      .phishguard-score-circle svg { width: 80px; height: 80px; transform: rotate(-90deg); }
      .phishguard-score-circle circle { fill: none; stroke-width: 6; }
      .phishguard-score-circle .bg { stroke: #334155; }
      .phishguard-score-circle .progress { stroke-linecap: round; transition: stroke-dashoffset 0.5s ease; }
      .phishguard-score-value { position: absolute; font-size: 24px; font-weight: 700; color: #f1f5f9; }
      .phishguard-score-label { color: #94a3b8; font-size: 14px; }
      .phishguard-reasons { list-style: none; padding: 0; margin: 0; }
      .phishguard-reasons li { display: flex; align-items: flex-start; gap: 10px; padding: 10px 12px; background: #0f172a; border-radius: 8px; margin-bottom: 8px; color: #e2e8f0; font-size: 14px; line-height: 1.5; }
      .phishguard-reasons li:last-child { margin-bottom: 0; }
      .phishguard-reasons .icon { flex-shrink: 0; width: 20px; height: 20px; color: currentColor; }
      .phishguard-recommendations { display: flex; flex-direction: column; gap: 10px; }
      .phishguard-recommendation { display: flex; align-items: flex-start; gap: 10px; padding: 12px; background: #0f172a; border-radius: 8px; color: #e2e8f0; font-size: 14px; line-height: 1.5; border-left: 3px solid; }
      .phishguard-recommendation.high { border-left-color: #ef4444; }
      .phishguard-recommendation.medium { border-left-color: #f59e0b; }
      .phishguard-recommendation.low { border-left-color: #10b981; }
      .phishguard-breakdown { display: grid; grid-template-columns: repeat(2, 1fr); gap: 12px; }
      .phishguard-breakdown-item { background: #0f172a; padding: 14px; border-radius: 8px; }
      .phishguard-breakdown-label { font-size: 12px; color: #94a3b8; margin-bottom: 4px; }
      .phishguard-breakdown-value { font-size: 20px; font-weight: 700; color: #f1f5f9; }
      .phishguard-actions { display: flex; gap: 10px; padding-top: 16px; border-top: 1px solid #334155; }
      .phishguard-btn { flex: 1; padding: 12px 16px; border-radius: 8px; font-size: 14px; font-weight: 600; cursor: pointer; border: none; transition: opacity 0.2s; }
      .phishguard-btn:hover { opacity: 0.9; }
      .phishguard-btn-primary { background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%); color: white; }
      .phishguard-btn-secondary { background: #334155; color: #e2e8f0; }
    </style>
    <div id="phishguard-modal-overlay">
      <div id="phishguard-modal">
        <div class="phishguard-header">
          <h2>PhishGuard AI Analysis</h2>
          <span class="phishguard-badge ${e.finalPrediction.toLowerCase()}">
            ${B(e.finalPrediction)} ${e.finalPrediction}
          </span>
        </div>
        <div class="phishguard-content">
          <div class="phishguard-section">
            <div class="phishguard-section-title">Risk Score</div>
            <div class="phishguard-score">
              <div class="phishguard-score-circle">
                <svg viewBox="0 0 80 80">
                  <circle class="bg" cx="40" cy="40" r="34"></circle>
                  <circle class="progress ${T(e.finalThreatLevel)}" 
                    cx="40" cy="40" r="34"
                    stroke-dasharray="213.6"
                    stroke-dashoffset="${M(e.finalRiskScore)}">
                  </circle>
                </svg>
                <span class="phishguard-score-value">${e.finalRiskScore}</span>
              </div>
              <div>
                <div class="phishguard-score-label">Threat Level: <strong style="color: ${R(e.finalThreatLevel)}">${e.finalThreatLevel}</strong></div>
                <div class="phishguard-score-label">Confidence: <strong>${e.finalConfidence}%</strong></div>
                <div class="phishguard-score-label">Sources: ${q(e.sources)}</div>
              </div>
            </div>
          </div>
          
          ${e.explanation.riskIndicators&&e.explanation.riskIndicators.length>0?`
          <div class="phishguard-section">
            <div class="phishguard-section-title">Risk Indicators</div>
            <ul class="phishguard-reasons">
              ${e.explanation.riskIndicators.map(r=>`
                <li>
                  <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <circle cx="12" cy="12" r="10"></circle>
                    <line x1="12" y1="8" x2="12" y2="12"></line>
                    <line x1="12" y1="16" x2="12.01" y2="16"></line>
                  </svg>
                  ${r}
                </li>
              `).join("")}
            </ul>
          </div>
          `:""}
          
          <div class="phishguard-section">
            <div class="phishguard-section-title">Recommendations</div>
            <div class="phishguard-recommendations">
              ${((o=e.explanation.recommendations)==null?void 0:o.map((r,c)=>`
                <div class="phishguard-recommendation ${e.finalThreatLevel.toLowerCase()}">
                  <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <polyline points="9 18 15 12 9 6"></polyline>
                  </svg>
                  ${r}
                </div>
              `).join(""))||""}
            </div>
          </div>
          
          ${e.explanation.breakdown?`
          <div class="phishguard-section">
            <div class="phishguard-section-title">Score Breakdown</div>
            <div class="phishguard-breakdown">
              ${e.explanation.breakdown.localScore!==void 0?`
              <div class="phishguard-breakdown-item">
                <div class="phishguard-breakdown-label">Local Analysis</div>
                <div class="phishguard-breakdown-value">${e.explanation.breakdown.localScore}</div>
              </div>
              `:""}
              ${e.explanation.breakdown.backendScore!==void 0?`
              <div class="phishguard-breakdown-item">
                <div class="phishguard-breakdown-label">Backend ML</div>
                <div class="phishguard-breakdown-value">${e.explanation.breakdown.backendScore}</div>
              </div>
              `:""}
              ${e.explanation.breakdown.threatIntelScore!==void 0?`
              <div class="phishguard-breakdown-item">
                <div class="phishguard-breakdown-label">Threat Intel</div>
                <div class="phishguard-breakdown-value">${e.explanation.breakdown.threatIntelScore}</div>
              </div>
              `:""}
              <div class="phishguard-breakdown-item">
                <div class="phishguard-breakdown-label">Final Score</div>
                <div class="phishguard-breakdown-value">${e.finalRiskScore}</div>
              </div>
            </div>
          </div>
          `:""}
          
          <div class="phishguard-actions">
            <button class="phishguard-btn phishguard-btn-secondary" id="phishguard-close-modal">Close</button>
            <button class="phishguard-btn phishguard-btn-primary" id="phishguard-report">Report False Positive</button>
          </div>
        </div>
      </div>
    </div>
  `,document.body.appendChild(i),i.querySelector("#phishguard-close-modal").addEventListener("click",()=>i.remove()),i.querySelector("#phishguard-modal-overlay").addEventListener("click",r=>{r.target===i.querySelector("#phishguard-modal-overlay")&&i.remove()}),i.querySelector("#phishguard-report").addEventListener("click",()=>{chrome.runtime.sendMessage({action:"reportFeedback",data:{url:window.location.href,prediction:e.finalPrediction,correct:!1}}),alert("Thank you for reporting! This helps improve PhishGuard AI."),i.remove()});const n=r=>{r.key==="Escape"&&(i.remove(),document.removeEventListener("keydown",n))};document.addEventListener("keydown",n)}function y(e){const a=document.getElementById("phishguard-warning-banner");a&&a.remove();const i=document.createElement("div");i.id="phishguard-warning-banner",i.innerHTML=`
    <style>
      #phishguard-warning-banner {
        position: fixed;
        top: 0; left: 0; right: 0;
        z-index: 2147483647;
        padding: 14px 20px;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        font-size: 14px;
        line-height: 1.5;
        animation: phishguard-slide-down 0.3s ease;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
      }
      @keyframes phishguard-slide-down { from { transform: translateY(-100%); } to { transform: translateY(0); } }
      #phishguard-warning-banner.phishing { background: linear-gradient(135deg, #991b1b 0%, #ef4444 100%); color: white; }
      #phishguard-warning-banner.suspicious { background: linear-gradient(135deg, #92400e 0%, #f59e0b 100%); color: white; }
      .phishguard-banner-content { max-width: 1200px; margin: 0 auto; display: flex; align-items: center; justify-content: space-between; gap: 16px; flex-wrap: wrap; }
      .phishguard-banner-text { display: flex; align-items: center; gap: 12px; flex: 1; min-width: 280px; }
      .phishguard-banner-icon { width: 24px; height: 24px; flex-shrink: 0; }
      .phishguard-banner-actions { display: flex; gap: 8px; flex-shrink: 0; }
      .phishguard-banner-btn { padding: 8px 16px; border-radius: 6px; font-size: 13px; font-weight: 600; cursor: pointer; border: none; transition: opacity 0.2s; }
      .phishguard-banner-btn:hover { opacity: 0.9; }
      .phishguard-banner-btn-primary { background: white; color: #991b1b; }
      .phishguard-banner-btn-secondary { background: rgba(255,255,255,0.2); color: white; border: 1px solid rgba(255,255,255,0.3); }
      .phishguard-banner-btn-suspicious-primary { background: white; color: #92400e; }
      .phishguard-banner-btn-suspicious-secondary { background: rgba(255,255,255,0.2); color: white; border: 1px solid rgba(255,255,255,0.3); }
    </style>
    <div class="phishguard-banner-content">
      <div class="phishguard-banner-text">
        <svg class="phishguard-banner-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path>
          <line x1="12" y1="9" x2="12" y2="13"></line>
          <line x1="12" y1="17" x2="12.01" y2="17"></line>
        </svg>
        <span><strong>PhishGuard AI:</strong> This page is <strong>${e.prediction}</strong> (${e.level} risk). ${e.message}</span>
      </div>
      <div class="phishguard-banner-actions">
        <button class="phishguard-banner-btn phishguard-banner-btn-${e.level.toLowerCase()}-primary" id="phishguard-banner-analyze">View Details</button>
        <button class="phishguard-banner-btn phishguard-banner-btn-${e.level.toLowerCase()}-secondary" id="phishguard-banner-dismiss">Dismiss</button>
      </div>
    </div>
  `;const n=String(e.prediction??"").toLowerCase(),o=String(e.level??"").toLowerCase(),r=n.includes("phish")||o==="high"?"phishing":"suspicious";i.className=r,document.body.insertBefore(i,document.body.firstChild),document.body.style.paddingTop=i.offsetHeight+"px";const c=r==="phishing"?"":"-suspicious",u=i.querySelector("#phishguard-banner-analyze");u.className=`phishguard-banner-btn phishguard-banner-btn${c}-primary`;const f=i.querySelector("#phishguard-banner-dismiss");f.className=`phishguard-banner-btn phishguard-banner-btn${c}-secondary`,u.addEventListener("click",()=>{chrome.runtime.sendMessage({action:"analyze",url:window.location.href},l=>{chrome.runtime.lastError||!l||!l.success||d(l.data)}),s(),i.remove(),document.body.style.paddingTop=""}),f.addEventListener("click",()=>{s(),i.remove(),document.body.style.paddingTop=""})}const b={autoProtectLevel:"suspicious",blockHighRiskPages:!0};async function z(){try{const e=await chrome.storage.local.get("phishguard_settings");return{...b,...e.phishguard_settings??{}}}catch{return{...b}}}function s(){try{sessionStorage.setItem(`pgai-dismissed:${window.location.href}`,"1")}catch{}}function E(){try{return sessionStorage.getItem(`pgai-dismissed:${window.location.href}`)==="1"}catch{return!1}}async function v(){const e=await z();if(chrome.storage.local.get("phishguard_settings",a=>{const i=a.phishguard_settings||{};i.showBadge!==!1&&i.autoAnalyze!==!1&&!document.getElementById("phishguard-float-btn")&&g()}),e.autoProtectLevel!=="off"&&/^https?:/i.test(window.location.href))try{const a=await h(window.location.href);P(p(a),e)}catch{}}function P(e,a){E()||(e.finalPrediction==="Phishing"?(y({prediction:"PHISHING",level:"HIGH",message:e.explanation.summary||"Strong phishing indicators detected on this page."}),a.blockHighRiskPages&&e.finalRiskScore>=85&&$(e)):e.finalPrediction==="Suspicious"&&A(e))}function $(e){if(document.getElementById("pgai-block-page"))return;const a=(e.explanation.riskIndicators??[]).slice(0,4),i=document.createElement("div");i.id="pgai-block-page",i.innerHTML=`
    <style>
      #pgai-block-page {
        position: fixed; inset: 0; z-index: 2147483647;
        background: rgba(5, 8, 20, 0.96);
        display: flex; align-items: center; justify-content: center;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      }
      #pgai-block-card {
        max-width: 520px; width: 90%;
        background: #161b2e; border: 1px solid #ef4444;
        border-radius: 16px; padding: 32px; color: #f1f5f9;
        box-shadow: 0 25px 60px rgba(239, 68, 68, 0.25);
      }
      #pgai-block-card h1 { margin: 0 0 6px; font-size: 22px; color: #ef4444; }
      #pgai-block-url { color: #94a3b8; font-size: 13px; word-break: break-all; margin-bottom: 16px; }
      .pgai-block-reasons { margin: 0 0 20px; padding-left: 18px; color: #e2e8f0; font-size: 14px; line-height: 1.7; }
      .pgai-block-actions { display: flex; gap: 12px; align-items: center; }
      #pgai-go-back {
        flex: 1; padding: 12px 18px; border: none; border-radius: 10px;
        background: linear-gradient(135deg, #3b82f6, #2563eb);
        color: white; font-size: 15px; font-weight: 700; cursor: pointer;
      }
      #pgai-continue {
        background: none; border: none; color: #64748b; font-size: 13px;
        cursor: pointer; text-decoration: underline;
      }
    </style>
    <div id="pgai-block-card">
      <h1>&#9940; Dangerous page blocked</h1>
      <div id="pgai-block-url">${m(window.location.href)}</div>
      <ul class="pgai-block-reasons">
        ${a.map(n=>`<li>${m(String(n))}</li>`).join("")}
        <li><strong>Risk score: ${e.finalRiskScore}/100</strong></li>
      </ul>
      <div class="pgai-block-actions">
        <button id="pgai-go-back">Go back to safety</button>
        <button id="pgai-continue">Continue anyway</button>
      </div>
    </div>
  `,document.documentElement.appendChild(i),i.querySelector("#pgai-go-back").addEventListener("click",()=>{s(),history.length>1?history.back():window.location.href="about:blank"}),i.querySelector("#pgai-continue").addEventListener("click",()=>{s(),i.remove()})}function A(e){if(document.getElementById("pgai-suspicious-chip"))return;const a=document.createElement("div");a.id="pgai-suspicious-chip",a.innerHTML=`
    <style>
      #pgai-suspicious-chip {
        position: fixed; bottom: 84px; left: 20px; z-index: 2147483646;
        padding: 8px 14px; border-radius: 999px; cursor: pointer;
        background: rgba(146, 64, 14, 0.95); color: #fff;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        font-size: 12.5px; font-weight: 600;
        box-shadow: 0 4px 14px rgba(0,0,0,0.35);
        transition: transform .15s ease;
      }
      #pgai-suspicious-chip:hover { transform: translateY(-2px); }
    </style>
    &#9888; Suspicious &middot; score ${e.finalRiskScore}
  `,a.addEventListener("click",()=>{d(e),a.remove()}),document.body.appendChild(a)}function m(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function B(e){switch(e){case"Phishing":return"🔴";case"Suspicious":return"🟠";case"Safe":return"🟢";default:return"⚪"}}function T(e){switch(e){case"High":return"phishing";case"Medium":return"suspicious";case"Low":return"safe";default:return"safe"}}function M(e){return 2*Math.PI*34*(1-e/100)}function R(e){switch(e){case"High":return"#ef4444";case"Medium":return"#f59e0b";case"Low":return"#10b981";default:return"#64748b"}}function q(e){const a=[];return e.local&&a.push("Local"),e.backend&&a.push("Backend ML"),e.threatIntel&&a.push("Threat Intel"),a.join(" + ")||"Local"}v();chrome.storage.onChanged.addListener((e,a)=>{if(a==="local"&&e.phishguard_settings){const i=e.phishguard_settings.newValue,n=document.getElementById("phishguard-float-btn");i.showBadge===!1&&n?n.remove():i.showBadge!==!1&&!n&&i.autoAnalyze!==!1&&g(),v()}});console.log("[ContentScript] PhishGuard AI content script loaded");
