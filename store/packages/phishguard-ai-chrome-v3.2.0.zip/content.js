function m(e){return new Promise((i,a)=>{chrome.runtime.sendMessage({action:"analyze",url:e},n=>{if(chrome.runtime.lastError){a(new Error(chrome.runtime.lastError.message));return}n&&n.success&&n.data?i(n.data):a(new Error((n==null?void 0:n.error)||"Analysis failed"))})})}function b(e){const i=Number(e.risk_score??0),a=String(e.prediction??"safe").toLowerCase(),n=a==="phishing"?"Phishing":a==="suspicious"?"Suspicious":"Safe",r=a==="phishing"?"High":a==="suspicious"?"Medium":"Low",t=Number(e.confidence??0);return{finalPrediction:n,finalConfidence:t>1?Math.round(t):Math.round(t*100),finalRiskScore:i,finalThreatLevel:r,sources:{local:!1,backend:!0,threatIntel:!1},explanation:{summary:e.summary||"",riskIndicators:Array.isArray(e.reasons)?e.reasons:[],recommendations:Array.isArray(e.security_tips)?e.security_tips:[],breakdown:{backendScore:i}},analyzedAt:e.analyzed_at||new Date().toISOString(),isCached:!!e.isCached}}chrome.runtime.onMessage.addListener((e,i,a)=>{switch(e.action){case"showAnalysis":d(e.data),a({success:!0});break;case"showWarning":L(e.data),a({success:!0});break;case"injectUI":x(e.data),a({success:!0});break;case"getPageInfo":a(S());break;case"analyzePage":return T().then(n=>a(n)),!0}return!0});function S(){var e,i;return{url:window.location.href,title:document.title,domain:window.location.hostname,forms:P(),links:z(),scripts:A(),iframes:$(),meta:B(),textContent:((i=(e=document.body)==null?void 0:e.innerText)==null?void 0:i.substring(0,5e3))||""}}function P(){return Array.from(document.forms).map(i=>({action:i.action,method:i.method,inputs:Array.from(i.elements).map(a=>({type:a.type,name:a.name,id:a.id,value:a.type==="password"?"[REDACTED]":a.value}))}))}function z(){return Array.from(document.querySelectorAll("a[href]")).slice(0,50).map(i=>{var a;return{href:i.href,text:(a=i.textContent)==null?void 0:a.trim().substring(0,100),target:i.target,rel:i.rel}})}function A(){return Array.from(document.querySelectorAll("script[src]")).map(i=>({src:i.src,async:i.async,defer:i.defer}))}function $(){return Array.from(document.querySelectorAll("iframe[src]")).map(i=>({src:i.src,width:i.width,height:i.height}))}function B(){const e=Array.from(document.querySelectorAll("meta")),i={};return e.forEach(a=>{a.name&&(i[a.name]=a.content);const n=a.getAttribute("property");n&&(i[n]=a.content)}),i}async function T(){const e=S(),i=e.forms.some(a=>a.inputs.some(n=>n.type==="password")||a.inputs.some(n=>/user|email|login|signin/i.test(n.name||"")));try{const a=b(await m(e.url)),n=[...a.explanation.riskIndicators,...i?["Login form detected on page"]:[]];return i&&!n.includes("Login form detected on page")&&n.push("Login form detected on page"),{...a,explanation:{...a.explanation,riskIndicators:n,recommendations:i&&a.finalThreatLevel!=="Low"?["DO NOT enter credentials on this page",...a.explanation.recommendations]:a.explanation.recommendations},pageInfo:{hasLoginForm:i,formsCount:e.forms.length,linksCount:e.links.length,scriptsCount:e.scripts.length,iframesCount:e.iframes.length}}}catch(a){return{finalPrediction:"Unknown",finalConfidence:0,finalRiskScore:0,finalThreatLevel:"Unknown",sources:{local:!0,backend:!1,threatIntel:!1},explanation:{summary:"Backend unavailable - only basic page checks were performed.",riskIndicators:[...i?["Login form detected on page"]:[]],recommendations:["Verify the site authenticity before entering sensitive data"],breakdown:{}},analyzedAt:new Date().toISOString(),error:a instanceof Error?a.message:String(a),pageInfo:{hasLoginForm:i,formsCount:e.forms.length,linksCount:e.links.length,scriptsCount:e.scripts.length,iframesCount:e.iframes.length}}}}function x(e){if(document.getElementById("phishguard-float-btn"))return;const i=document.createElement("div");i.id="phishguard-float-btn",i.innerHTML=`
    <style>
      #phishguard-float-btn {
        position: fixed;
        bottom: 20px;
        right: 20px;
        width: 56px;
        height: 56px;
        border-radius: 28px;
        background: linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%);
        box-shadow: 0 4px 20px rgba(30, 58, 138, 0.4);
        cursor: pointer;
        z-index: 2147483647;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: transform 0.2s, box-shadow 0.2s;
        border: none;
      }
      #phishguard-float-btn:hover {
        transform: scale(1.1);
        box-shadow: 0 6px 28px rgba(30, 58, 138, 0.5);
      }
      #phishguard-float-btn.phishguard-safe { background: linear-gradient(135deg, #065f46 0%, #10b981 100%); }
      #phishguard-float-btn.phishguard-suspicious { background: linear-gradient(135deg, #92400e 0%, #f59e0b 100%); }
      #phishguard-float-btn.phishguard-phishing { background: linear-gradient(135deg, #991b1b 0%, #ef4444 100%); animation: phishguard-pulse 2s infinite; }
      @keyframes phishguard-pulse { 0%, 100% { box-shadow: 0 4px 20px rgba(239, 68, 68, 0.4); } 50% { box-shadow: 0 4px 30px rgba(239, 68, 68, 0.7); } }
      #phishguard-float-btn svg { width: 28px; height: 28px; color: white; }
      #phishguard-tooltip {
        position: absolute;
        bottom: 70px;
        right: 0;
        background: #1e293b;
        color: white;
        padding: 8px 12px;
        border-radius: 6px;
        font-size: 12px;
        white-space: nowrap;
        opacity: 0;
        visibility: hidden;
        transition: opacity 0.2s, visibility 0.2s;
        pointer-events: none;
      }
      #phishguard-float-btn:hover #phishguard-tooltip {
        opacity: 1;
        visibility: visible;
      }
    </style>
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path>
      <path d="M9 12l2 2 4-4"></path>
    </svg>
    <div id="phishguard-tooltip">PhishGuard AI - Click to analyze</div>
  `,e?c(i,e.finalThreatLevel):(c(i,"Low"),m(window.location.href).then(a=>{document.getElementById("phishguard-float-btn")&&c(i,b(a).finalThreatLevel)}).catch(()=>{})),i.addEventListener("click",()=>{chrome.runtime.sendMessage({action:"analyze",url:window.location.href},a=>{chrome.runtime.lastError||!a||!a.success||(d(a.data),c(i,a.data.finalThreatLevel))})}),document.body.appendChild(i)}function c(e,i){switch(e.className="phishguard-float-btn",i){case"High":e.classList.add("phishguard-phishing"),e.querySelector("#phishguard-tooltip").textContent="⚠ Phishing detected - Click for details";break;case"Medium":e.classList.add("phishguard-suspicious"),e.querySelector("#phishguard-tooltip").textContent="⚠ Suspicious - Click for details";break;case"Low":default:e.classList.add("phishguard-safe"),e.querySelector("#phishguard-tooltip").textContent="✓ Safe - Click to re-analyze";break}}function d(e){var r;const i=document.getElementById("phishguard-modal");i&&i.remove();const a=document.createElement("div");a.id="phishguard-modal",a.innerHTML=`
    <style>
      #phishguard-modal-overlay {
        position: fixed;
        top: 0; left: 0; right: 0; bottom: 0;
        background: rgba(0, 0, 0, 0.7);
        z-index: 2147483646;
        display: flex;
        align-items: center;
        justify-content: center;
        animation: phishguard-fade-in 0.2s ease;
      }
      @keyframes phishguard-fade-in { from { opacity: 0; } to { opacity: 1; } }
      #phishguard-modal {
        background: #1e293b;
        border-radius: 16px;
        padding: 0;
        max-width: 520px;
        width: 90%;
        max-height: 85vh;
        overflow: hidden;
        box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
        border: 1px solid #334155;
        animation: phishguard-slide-up 0.3s ease;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      }
      @keyframes phishguard-slide-up { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
      .phishguard-header {
        padding: 20px 24px;
        border-bottom: 1px solid #334155;
        display: flex;
        align-items: center;
        justify-content: space-between;
      }
      .phishguard-header h2 { margin: 0; font-size: 18px; font-weight: 600; color: #f1f5f9; }
      .phishguard-badge {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 6px 14px;
        border-radius: 20px;
        font-size: 13px;
        font-weight: 600;
      }
      .phishguard-badge.phishing { background: rgba(239, 68, 68, 0.2); color: #ef4444; }
      .phishguard-badge.suspicious { background: rgba(245, 158, 11, 0.2); color: #f59e0b; }
      .phishguard-badge.safe { background: rgba(16, 185, 129, 0.2); color: #10b981; }
      .phishguard-close {
        background: none;
        border: none;
        color: #94a3b8;
        cursor: pointer;
        padding: 8px;
        border-radius: 8px;
        transition: background 0.2s, color 0.2s;
      }
      .phishguard-close:hover { background: #334155; color: #f1f5f9; }
      .phishguard-content { padding: 24px; overflow-y: auto; max-height: 60vh; }
      .phishguard-section { margin-bottom: 24px; }
      .phishguard-section:last-child { margin-bottom: 0; }
      .phishguard-section-title { font-size: 14px; font-weight: 600; color: #94a3b8; text-transform: uppercase; letter-spacing: 0.05em; margin-bottom: 12px; }
      .phishguard-score { display: flex; align-items: center; gap: 16px; }
      .phishguard-score-circle {
        width: 80px;
        height: 80px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        position: relative;
      }
      .phishguard-score-circle svg { width: 80px; height: 80px; transform: rotate(-90deg); }
      .phishguard-score-circle circle { fill: none; stroke-width: 6; }
      .phishguard-score-circle .bg { stroke: #334155; }
      .phishguard-score-circle .progress { stroke-linecap: round; transition: stroke-dashoffset 0.5s ease; }
      .phishguard-score-value { position: absolute; font-size: 24px; font-weight: 700; color: #f1f5f9; }
      .phishguard-score-label { color: #94a3b8; font-size: 14px; }
      .phishguard-reasons { list-style: none; padding: 0; margin: 0; }
      .phishguard-reasons li { display: flex; align-items: flex-start; gap: 10px; padding: 10px 12px; background: #0f172a; border-radius: 8px; margin-bottom: 8px; color: #e2e8f0; font-size: 14px; line-height: 1.5; }
      .phishguard-reasons li:last-child { margin-bottom: 0; }
      .phishguard-reasons .icon { flex-shrink: 0; width: 20px; height: 20px; color: currentColor; }
      .phishguard-recommendations { display: flex; flex-direction: column; gap: 10px; }
      .phishguard-recommendation { display: flex; align-items: flex-start; gap: 10px; padding: 12px; background: #0f172a; border-radius: 8px; color: #e2e8f0; font-size: 14px; line-height: 1.5; border-left: 3px solid; }
      .phishguard-recommendation.high { border-left-color: #ef4444; }
      .phishguard-recommendation.medium { border-left-color: #f59e0b; }
      .phishguard-recommendation.low { border-left-color: #10b981; }
      .phishguard-breakdown { display: grid; grid-template-columns: repeat(2, 1fr); gap: 12px; }
      .phishguard-breakdown-item { background: #0f172a; padding: 14px; border-radius: 8px; }
      .phishguard-breakdown-label { font-size: 12px; color: #94a3b8; margin-bottom: 4px; }
      .phishguard-breakdown-value { font-size: 20px; font-weight: 700; color: #f1f5f9; }
      .phishguard-actions { display: flex; gap: 10px; padding-top: 16px; border-top: 1px solid #334155; }
      .phishguard-btn { flex: 1; padding: 12px 16px; border-radius: 8px; font-size: 14px; font-weight: 600; cursor: pointer; border: none; transition: opacity 0.2s; }
      .phishguard-btn:hover { opacity: 0.9; }
      .phishguard-btn-primary { background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%); color: white; }
      .phishguard-btn-secondary { background: #334155; color: #e2e8f0; }
    </style>
    <div id="phishguard-modal-overlay">
      <div id="phishguard-modal">
        <div class="phishguard-header">
          <h2>PhishGuard AI Analysis</h2>
          <span class="phishguard-badge ${e.finalPrediction.toLowerCase()}">
            ${U(e.finalPrediction)} ${e.finalPrediction}
          </span>
        </div>
        <div class="phishguard-content">
          <div class="phishguard-section">
            <div class="phishguard-section-title">Risk Score</div>
            <div class="phishguard-score">
              <div class="phishguard-score-circle">
                <svg viewBox="0 0 80 80">
                  <circle class="bg" cx="40" cy="40" r="34"></circle>
                  <circle class="progress ${_(e.finalThreatLevel)}" 
                    cx="40" cy="40" r="34"
                    stroke-dasharray="213.6"
                    stroke-dashoffset="${O(e.finalRiskScore)}">
                  </circle>
                </svg>
                <span class="phishguard-score-value">${e.finalRiskScore}</span>
              </div>
              <div>
                <div class="phishguard-score-label">Threat Level: <strong style="color: ${V(e.finalThreatLevel)}">${e.finalThreatLevel}</strong></div>
                <div class="phishguard-score-label">Confidence: <strong>${e.finalConfidence}%</strong></div>
                <div class="phishguard-score-label">Sources: ${Y(e.sources)}</div>
              </div>
            </div>
          </div>
          
          ${e.explanation.riskIndicators&&e.explanation.riskIndicators.length>0?`
          <div class="phishguard-section">
            <div class="phishguard-section-title">Risk Indicators</div>
            <ul class="phishguard-reasons">
              ${e.explanation.riskIndicators.map(t=>`
                <li>
                  <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <circle cx="12" cy="12" r="10"></circle>
                    <line x1="12" y1="8" x2="12" y2="12"></line>
                    <line x1="12" y1="16" x2="12.01" y2="16"></line>
                  </svg>
                  ${t}
                </li>
              `).join("")}
            </ul>
          </div>
          `:""}
          
          <div class="phishguard-section">
            <div class="phishguard-section-title">Recommendations</div>
            <div class="phishguard-recommendations">
              ${((r=e.explanation.recommendations)==null?void 0:r.map((t,p)=>`
                <div class="phishguard-recommendation ${e.finalThreatLevel.toLowerCase()}">
                  <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <polyline points="9 18 15 12 9 6"></polyline>
                  </svg>
                  ${t}
                </div>
              `).join(""))||""}
            </div>
          </div>
          
          ${e.explanation.breakdown?`
          <div class="phishguard-section">
            <div class="phishguard-section-title">Score Breakdown</div>
            <div class="phishguard-breakdown">
              ${e.explanation.breakdown.localScore!==void 0?`
              <div class="phishguard-breakdown-item">
                <div class="phishguard-breakdown-label">Local Analysis</div>
                <div class="phishguard-breakdown-value">${e.explanation.breakdown.localScore}</div>
              </div>
              `:""}
              ${e.explanation.breakdown.backendScore!==void 0?`
              <div class="phishguard-breakdown-item">
                <div class="phishguard-breakdown-label">Backend ML</div>
                <div class="phishguard-breakdown-value">${e.explanation.breakdown.backendScore}</div>
              </div>
              `:""}
              ${e.explanation.breakdown.threatIntelScore!==void 0?`
              <div class="phishguard-breakdown-item">
                <div class="phishguard-breakdown-label">Threat Intel</div>
                <div class="phishguard-breakdown-value">${e.explanation.breakdown.threatIntelScore}</div>
              </div>
              `:""}
              <div class="phishguard-breakdown-item">
                <div class="phishguard-breakdown-label">Final Score</div>
                <div class="phishguard-breakdown-value">${e.finalRiskScore}</div>
              </div>
            </div>
          </div>
          `:""}
          
          <div class="phishguard-actions">
            <button class="phishguard-btn phishguard-btn-secondary" id="phishguard-close-modal">Close</button>
            <button class="phishguard-btn phishguard-btn-primary" id="phishguard-report">Report False Positive</button>
          </div>
        </div>
      </div>
    </div>
  `,document.body.appendChild(a),a.querySelector("#phishguard-close-modal").addEventListener("click",()=>a.remove()),a.querySelector("#phishguard-modal-overlay").addEventListener("click",t=>{t.target===a.querySelector("#phishguard-modal-overlay")&&a.remove()}),a.querySelector("#phishguard-report").addEventListener("click",()=>{chrome.runtime.sendMessage({action:"reportFeedback",data:{url:window.location.href,prediction:e.finalPrediction,correct:!1}}),alert("Thank you for reporting! This helps improve PhishGuard AI."),a.remove()});const n=t=>{t.key==="Escape"&&(a.remove(),document.removeEventListener("keydown",n))};document.addEventListener("keydown",n)}function L(e){const i=document.getElementById("phishguard-warning-banner");i&&i.remove();const a=document.createElement("div");a.id="phishguard-warning-banner",a.innerHTML=`
    <style>
      #phishguard-warning-banner {
        position: fixed;
        top: 0; left: 0; right: 0;
        z-index: 2147483647;
        padding: 14px 20px;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        font-size: 14px;
        line-height: 1.5;
        animation: phishguard-slide-down 0.3s ease;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
      }
      @keyframes phishguard-slide-down { from { transform: translateY(-100%); } to { transform: translateY(0); } }
      #phishguard-warning-banner.phishing { background: linear-gradient(135deg, #991b1b 0%, #ef4444 100%); color: white; }
      #phishguard-warning-banner.suspicious { background: linear-gradient(135deg, #92400e 0%, #f59e0b 100%); color: white; }
      .phishguard-banner-content { max-width: 1200px; margin: 0 auto; display: flex; align-items: center; justify-content: space-between; gap: 16px; flex-wrap: wrap; }
      .phishguard-banner-text { display: flex; align-items: center; gap: 12px; flex: 1; min-width: 280px; }
      .phishguard-banner-icon { width: 24px; height: 24px; flex-shrink: 0; }
      .phishguard-banner-actions { display: flex; gap: 8px; flex-shrink: 0; }
      .phishguard-banner-btn { padding: 8px 16px; border-radius: 6px; font-size: 13px; font-weight: 600; cursor: pointer; border: none; transition: opacity 0.2s; }
      .phishguard-banner-btn:hover { opacity: 0.9; }
      .phishguard-banner-btn-primary { background: white; color: #991b1b; }
      .phishguard-banner-btn-secondary { background: rgba(255,255,255,0.2); color: white; border: 1px solid rgba(255,255,255,0.3); }
      .phishguard-banner-btn-suspicious-primary { background: white; color: #92400e; }
      .phishguard-banner-btn-suspicious-secondary { background: rgba(255,255,255,0.2); color: white; border: 1px solid rgba(255,255,255,0.3); }
    </style>
    <div class="phishguard-banner-content">
      <div class="phishguard-banner-text">
        <svg class="phishguard-banner-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path>
          <line x1="12" y1="9" x2="12" y2="13"></line>
          <line x1="12" y1="17" x2="12.01" y2="17"></line>
        </svg>
        <span><strong>PhishGuard AI:</strong> This page is <strong>${e.prediction}</strong> (${e.level} risk). ${e.message}</span>
      </div>
      <div class="phishguard-banner-actions">
        <button class="phishguard-banner-btn phishguard-banner-btn-${e.level.toLowerCase()}-primary" id="phishguard-banner-analyze">View Details</button>
        <button class="phishguard-banner-btn phishguard-banner-btn-${e.level.toLowerCase()}-secondary" id="phishguard-banner-dismiss">Dismiss</button>
      </div>
    </div>
  `;const n=String(e.prediction??"").toLowerCase(),r=String(e.level??"").toLowerCase(),t=n.includes("phish")||r==="high"?"phishing":"suspicious";a.className=t,document.body.insertBefore(a,document.body.firstChild),document.body.style.paddingTop=a.offsetHeight+"px";const p=t==="phishing"?"":"-suspicious",w=a.querySelector("#phishguard-banner-analyze");w.className=`phishguard-banner-btn phishguard-banner-btn${p}-primary`;const y=a.querySelector("#phishguard-banner-dismiss");y.className=`phishguard-banner-btn phishguard-banner-btn${p}-secondary`,w.addEventListener("click",()=>{chrome.runtime.sendMessage({action:"analyze",url:window.location.href},h=>{chrome.runtime.lastError||!h||!h.success||d(h.data)}),l(),a.remove(),document.body.style.paddingTop=""}),y.addEventListener("click",()=>{l(),a.remove(),document.body.style.paddingTop=""})}const v={autoProtectLevel:"suspicious",blockHighRiskPages:!0};async function M(){try{const e=await chrome.storage.local.get("phishguard_settings");return{...v,...e.phishguard_settings??{}}}catch{return{...v}}}function l(){try{sessionStorage.setItem(`pgai-dismissed:${window.location.href}`,"1")}catch{}}function H(){try{return sessionStorage.getItem(`pgai-dismissed:${window.location.href}`)==="1"}catch{return!1}}async function I(){const e=await M();if(chrome.storage.local.get("phishguard_settings",i=>{const a=i.phishguard_settings||{};a.showBadge!==!1&&a.autoAnalyze!==!1&&!document.getElementById("phishguard-float-btn")&&x()}),e.autoProtectLevel!=="off"&&/^https?:/i.test(window.location.href))try{const i=await m(window.location.href);R(b(i),e)}catch{}}function R(e,i){F(e),!H()&&(e.finalPrediction==="Phishing"?(L({prediction:"PHISHING",level:"HIGH",message:e.explanation.summary||"Strong phishing indicators detected on this page."}),i.blockHighRiskPages&&e.finalRiskScore>=85&&q(e)):e.finalPrediction==="Suspicious"&&D(e))}function q(e){if(document.getElementById("pgai-block-page"))return;const i=(e.explanation.riskIndicators??[]).slice(0,4),a=document.createElement("div");a.id="pgai-block-page",a.innerHTML=`
    <style>
      #pgai-block-page {
        position: fixed; inset: 0; z-index: 2147483647;
        background: rgba(5, 8, 20, 0.96);
        display: flex; align-items: center; justify-content: center;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      }
      #pgai-block-card {
        max-width: 520px; width: 90%;
        background: #161b2e; border: 1px solid #ef4444;
        border-radius: 16px; padding: 32px; color: #f1f5f9;
        box-shadow: 0 25px 60px rgba(239, 68, 68, 0.25);
      }
      #pgai-block-card h1 { margin: 0 0 6px; font-size: 22px; color: #ef4444; }
      #pgai-block-url { color: #94a3b8; font-size: 13px; word-break: break-all; margin-bottom: 16px; }
      .pgai-block-reasons { margin: 0 0 20px; padding-left: 18px; color: #e2e8f0; font-size: 14px; line-height: 1.7; }
      .pgai-block-actions { display: flex; gap: 12px; align-items: center; }
      #pgai-go-back {
        flex: 1; padding: 12px 18px; border: none; border-radius: 10px;
        background: linear-gradient(135deg, #3b82f6, #2563eb);
        color: white; font-size: 15px; font-weight: 700; cursor: pointer;
      }
      #pgai-continue {
        background: none; border: none; color: #64748b; font-size: 13px;
        cursor: pointer; text-decoration: underline;
      }
    </style>
    <div id="pgai-block-card">
      <h1>&#9940; Dangerous page blocked</h1>
      <div id="pgai-block-url">${f(window.location.href)}</div>
      <ul class="pgai-block-reasons">
        ${i.map(n=>`<li>${f(String(n))}</li>`).join("")}
        <li><strong>Risk score: ${e.finalRiskScore}/100</strong></li>
      </ul>
      <div class="pgai-block-actions">
        <button id="pgai-go-back">Go back to safety</button>
        <button id="pgai-continue">Continue anyway</button>
      </div>
    </div>
  `,document.documentElement.appendChild(a),a.querySelector("#pgai-go-back").addEventListener("click",()=>{l(),history.length>1?history.back():window.location.href="about:blank"}),a.querySelector("#pgai-continue").addEventListener("click",()=>{l(),a.remove()})}function D(e){if(document.getElementById("pgai-suspicious-chip"))return;const i=document.createElement("div");i.id="pgai-suspicious-chip",i.innerHTML=`
    <style>
      #pgai-suspicious-chip {
        position: fixed; bottom: 84px; left: 20px; z-index: 2147483646;
        padding: 8px 14px; border-radius: 999px; cursor: pointer;
        background: rgba(146, 64, 14, 0.95); color: #fff;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        font-size: 12.5px; font-weight: 600;
        box-shadow: 0 4px 14px rgba(0,0,0,0.35);
        transition: transform .15s ease;
      }
      #pgai-suspicious-chip:hover { transform: translateY(-2px); }
    </style>
    &#9888; Suspicious &middot; score ${e.finalRiskScore}
  `,i.addEventListener("click",()=>{d(e),i.remove()}),document.body.appendChild(i)}let s=null,o=null,k=!1,g=!1;function F(e){const i=String((e==null?void 0:e.finalPrediction)??"").toLowerCase();if(i!=="phishing"&&i!=="suspicious"||(s=e,C()))return;const a=document.querySelector('input[type="password"]');a&&E(a),document.addEventListener("focusin",j,!0),window.addEventListener("scroll",u,{passive:!0}),window.addEventListener("resize",u,{passive:!0})}function j(e){const i=e.target;!i||i.type!=="password"||E(i)}function C(){try{return sessionStorage.getItem("pgai-pw-dismissed")==="1"}catch{return!1}}function N(){var e;try{sessionStorage.setItem("pgai-pw-dismissed","1")}catch{}(e=document.getElementById("pgai-pw-alarm"))==null||e.remove(),o=null}function E(e){if(C()||!document.documentElement.contains(e))return;o=e;let i=document.getElementById("pgai-pw-alarm");i||(i=document.createElement("div"),i.id="pgai-pw-alarm",document.body.appendChild(i));const a=String((s==null?void 0:s.finalPrediction)??"").toLowerCase()==="phishing";i.className=a?"danger":"warn",i.innerHTML=`
    <style>
      #pgai-pw-alarm {
        position: fixed; left: -9999px; top: -9999px; z-index: 2147483647;
        max-width: min(420px, calc(100vw - 24px));
        padding: 12px 16px; border-radius: 10px; color: #fff;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        font-size: 13px; line-height: 1.45;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.35);
        animation: pgai-pw-in 0.18s ease;
      }
      @keyframes pgai-pw-in { from { opacity: 0; transform: translateY(-6px); } to { opacity: 1; transform: translateY(0); } }
      #pgai-pw-alarm.danger { background: linear-gradient(135deg, #991b1b, #ef4444); border: 1px solid #fca5a5; }
      #pgai-pw-alarm.warn { background: linear-gradient(135deg, #92400e, #f59e0b); border: 1px solid #fde68a; }
      .pgai-pw-row { display: flex; align-items: flex-start; gap: 10px; }
      .pgai-pw-icon { width: 20px; height: 20px; flex-shrink: 0; margin-top: 1px; }
      .pgai-pw-text strong { display: block; font-size: 13.5px; margin-bottom: 2px; }
      .pgai-pw-actions { display: flex; gap: 8px; margin-top: 10px; }
      .pgai-pw-btn { padding: 6px 12px; border-radius: 6px; font-size: 12px; font-weight: 700; cursor: pointer; border: none; }
      #pgai-pw-details { background: rgba(255, 255, 255, 0.22); color: #fff; }
      #pgai-pw-dismiss { background: #fff; color: #7f1d1d; }
      #pgai-pw-alarm.warn #pgai-pw-dismiss { color: #78350f; }
    </style>
    <div class="pgai-pw-row">
      <svg class="pgai-pw-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path>
        <line x1="12" y1="9" x2="12" y2="13"></line>
        <line x1="12" y1="17" x2="12.01" y2="17"></line>
      </svg>
      <div class="pgai-pw-text">
        <strong>${a?"&#9940; Do NOT enter your password":"&#9888; Avoid entering your password"}</strong>
        PhishGuard flagged this page (${f(window.location.hostname)}) as
        <strong>${a?"PHISHING":"SUSPICIOUS"}</strong>.
      </div>
    </div>
    <div class="pgai-pw-actions">
      <button class="pgai-pw-btn" id="pgai-pw-details">View details</button>
      <button class="pgai-pw-btn" id="pgai-pw-dismiss">Dismiss</button>
    </div>
  `,i.querySelector("#pgai-pw-dismiss").addEventListener("click",N),i.querySelector("#pgai-pw-details").addEventListener("click",()=>{s&&d(s)}),G(),u()}function u(){const e=document.getElementById("pgai-pw-alarm");if(e){if(!o||!document.documentElement.contains(o)){o=null,e.remove();return}g||(g=!0,requestAnimationFrame(()=>{g=!1;const i=document.getElementById("pgai-pw-alarm");if(!i)return;if(!o||!document.documentElement.contains(o)){o=null,i.remove();return}const a=o.getBoundingClientRect(),n=Math.max(12,Math.min(a.left,window.innerWidth-i.offsetWidth-12)),r=a.top-i.offsetHeight-10;i.style.left=`${n}px`,i.style.top=`${r>=12?r:Math.min(a.bottom+10,window.innerHeight-i.offsetHeight-12)}px`}))}}function G(){if(!k){k=!0;try{chrome.runtime.sendMessage({action:"notifyPasswordAlarm",data:{url:window.location.href}},()=>void chrome.runtime.lastError)}catch{}}}function f(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function U(e){switch(e){case"Phishing":return"🔴";case"Suspicious":return"🟠";case"Safe":return"🟢";default:return"⚪"}}function _(e){switch(e){case"High":return"phishing";case"Medium":return"suspicious";case"Low":return"safe";default:return"safe"}}function O(e){return 2*Math.PI*34*(1-e/100)}function V(e){switch(e){case"High":return"#ef4444";case"Medium":return"#f59e0b";case"Low":return"#10b981";default:return"#64748b"}}function Y(e){const i=[];return e.local&&i.push("Local"),e.backend&&i.push("Backend ML"),e.threatIntel&&i.push("Threat Intel"),i.join(" + ")||"Local"}I();chrome.storage.onChanged.addListener((e,i)=>{if(i==="local"&&e.phishguard_settings){const a=e.phishguard_settings.newValue,n=document.getElementById("phishguard-float-btn");a.showBadge===!1&&n?n.remove():a.showBadge!==!1&&!n&&a.autoAnalyze!==!1&&x(),I()}});console.log("[ContentScript] PhishGuard AI content script loaded");
