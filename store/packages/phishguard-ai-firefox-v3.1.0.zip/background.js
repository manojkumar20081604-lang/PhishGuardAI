const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["textDetector.js","cache.js","metricsApi.js"])))=>i.map(i=>d[i]);
var _a, _b;
import { S as ScanApiClient, D as DEFAULT_BASE_URL, c as clear, l as list, i as isDbReady, s as set, g as get } from "./cache.js";
import { M as MetricsApiClient } from "./metricsApi.js";
const scriptRel = "modulepreload";
const assetsURL = function(dep) {
  return "/" + dep;
};
const seen = {};
const __vitePreload = function preload(baseModule, deps, importerUrl) {
  let promise = Promise.resolve();
  if (deps && deps.length > 0) {
    document.getElementsByTagName("link");
    const cspNonceMeta = document.querySelector(
      "meta[property=csp-nonce]"
    );
    const cspNonce = (cspNonceMeta == null ? void 0 : cspNonceMeta.nonce) || (cspNonceMeta == null ? void 0 : cspNonceMeta.getAttribute("nonce"));
    promise = Promise.allSettled(
      deps.map((dep) => {
        dep = assetsURL(dep);
        if (dep in seen) return;
        seen[dep] = true;
        const isCss = dep.endsWith(".css");
        const cssSelector = isCss ? '[rel="stylesheet"]' : "";
        if (document.querySelector(`link[href="${dep}"]${cssSelector}`)) {
          return;
        }
        const link = document.createElement("link");
        link.rel = isCss ? "stylesheet" : scriptRel;
        if (!isCss) {
          link.as = "script";
        }
        link.crossOrigin = "";
        link.href = dep;
        if (cspNonce) {
          link.setAttribute("nonce", cspNonce);
        }
        document.head.appendChild(link);
        if (isCss) {
          return new Promise((res, rej) => {
            link.addEventListener("load", res);
            link.addEventListener(
              "error",
              () => rej(new Error(`Unable to preload CSS for ${dep}`))
            );
          });
        }
      })
    );
  }
  function handlePreloadError(err) {
    const e = new Event("vite:preloadError", {
      cancelable: true
    });
    e.payload = err;
    window.dispatchEvent(e);
    if (!e.defaultPrevented) {
      throw err;
    }
  }
  return promise.then((res) => {
    for (const item of res || []) {
      if (item.status !== "rejected") continue;
      handlePreloadError(item.reason);
    }
    return baseModule().catch(handlePreloadError);
  });
};
const FEATURE_NAMES = [
  "url_length",
  "has_https",
  "has_at_symbol",
  "has_ip_address",
  "dash_count",
  "digit_ratio",
  "special_char_count",
  "subdomain_count",
  "suspicious_tld",
  "char_diversity"
];
const IP_PATTERN = /\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/;
const SPECIAL_CHARS = new Set("._~:/?#[]@!$&'()*+,;=".split(""));
const SUSPICIOUS_TLDS$1 = [".xyz", ".top", ".pw", ".tk", ".ml", ".ga", ".cf", ".gq", ".club"];
function pyNetloc$1(url) {
  let rest = url;
  const schemeIdx = rest.indexOf("://");
  if (schemeIdx !== -1) rest = rest.slice(schemeIdx + 3);
  const slashIdx = rest.indexOf("/");
  if (slashIdx !== -1) rest = rest.slice(0, slashIdx);
  const qIdx = rest.search(/[?#]/);
  if (qIdx !== -1) rest = rest.slice(0, qIdx);
  return rest;
}
function extractUrlFeatures(url) {
  const len = url.length;
  const netloc = pyNetloc$1(url);
  const subdomainCount = netloc ? Math.max(0, netloc.split(".").length - 2) : 0;
  let digits = 0;
  let special = 0;
  for (const c of url) {
    if (c >= "0" && c <= "9") digits++;
    if (SPECIAL_CHARS.has(c)) special++;
  }
  return new Float32Array([
    len,
    // url_length
    url.startsWith("https") ? 1 : 0,
    // has_https
    url.includes("@") ? 1 : 0,
    // has_at_symbol
    IP_PATTERN.test(url) ? 1 : 0,
    // has_ip_address
    (url.match(/-/g) || []).length,
    // dash_count
    digits / Math.max(len, 1),
    // digit_ratio
    special,
    // special_char_count
    subdomainCount,
    // subdomain_count
    SUSPICIOUS_TLDS$1.some((t) => url.toLowerCase().endsWith(t)) ? 1 : 0,
    // suspicious_tld
    new Set(url).size / Math.max(len, 1)
    // char_diversity
  ]);
}
const THRESHOLDS = { phishing: 0.65, suspicious: 0.35 };
const MODEL_FILE = "models/url-model-v3.onnx";
let sessionPromise = null;
let modelBaseOverride = null;
function modelBaseUrl() {
  var _a2;
  if (modelBaseOverride !== null) return modelBaseOverride;
  if (typeof chrome !== "undefined" && ((_a2 = chrome.runtime) == null ? void 0 : _a2.getURL)) {
    return chrome.runtime.getURL("");
  }
  return "/";
}
function isNodeRuntime() {
  var _a2;
  return typeof process !== "undefined" && !!((_a2 = process.versions) == null ? void 0 : _a2.node);
}
function __setModelBaseForTests(base) {
  modelBaseOverride = base;
  sessionPromise = null;
}
async function loadSession() {
  const useNode = isNodeRuntime();
  let ort;
  let executionProviders;
  if (useNode) {
    ort = await __vitePreload(() => import("./index.js").then((n) => n.i), true ? [] : void 0);
    executionProviders = ["cpu"];
  } else {
    ort = await __vitePreload(() => import("./ort.wasm.bundle.min.js"), true ? [] : void 0);
    ort.env.wasm.numThreads = 1;
    ort.env.wasm.wasmPaths = `${modelBaseUrl()}vendor/ort/`;
    executionProviders = ["wasm"];
  }
  const session = await ort.InferenceSession.create(`${modelBaseUrl()}${MODEL_FILE}`, {
    executionProviders,
    graphOptimizationLevel: "all"
  });
  return { session, ort };
}
async function loadModel() {
  sessionPromise ?? (sessionPromise = loadSession());
  await sessionPromise;
}
async function predictUrlProbability(url) {
  const { session, ort } = await (sessionPromise ?? (sessionPromise = loadSession()));
  const inputName = session.inputNames[0] ?? "float_input";
  const feeds = {
    [inputName]: new ort.Tensor("float32", extractUrlFeatures(url), [1, FEATURE_NAMES.length])
  };
  const results = await session.run(feeds);
  const probaName = Object.keys(results).find((k) => k.toLowerCase().includes("prob")) ?? Object.keys(results)[Object.keys(results).length - 1];
  const data = results[probaName].data;
  return data.length === 2 ? data[1] : data[0];
}
async function predictUrl(url) {
  const p = await predictUrlProbability(url);
  if (p >= THRESHOLDS.phishing) return { prediction: "phishing", confidence: round(p) };
  if (p >= THRESHOLDS.suspicious) return { prediction: "suspicious", confidence: round(p) };
  return { prediction: "safe", confidence: round(1 - p) };
}
function round(v) {
  return Math.round(v * 1e3) / 1e3;
}
const engine = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  __setModelBaseForTests,
  loadModel,
  predictUrl,
  predictUrlProbability
}, Symbol.toStringTag, { value: "Module" }));
const SUSPICIOUS_TLDS = [".xyz", ".top", ".pw", ".tk", ".ml", ".ga", ".cf", ".gq", ".club", ".work", ".date"];
const SAFE_DOMAINS = ["google.com", "facebook.com", "microsoft.com", "amazon.com", "apple.com", "paypal.com"];
const ESTABLISHED_TLDS = ["com", "org", "net", "edu", "gov", "co"];
function pyNetloc(url) {
  let rest = url;
  const schemeIdx = rest.indexOf("://");
  if (schemeIdx !== -1) rest = rest.slice(schemeIdx + 3);
  const slashIdx = rest.indexOf("/");
  if (slashIdx !== -1) rest = rest.slice(0, slashIdx);
  const qIdx = rest.search(/[?#]/);
  if (qIdx !== -1) rest = rest.slice(0, qIdx);
  return { netloc: rest.toLowerCase(), domain: rest.toLowerCase() };
}
function explainUrl(url, prediction, features) {
  const explanations = [];
  const riskIndicators = [];
  const safeIndicators = [];
  const lower = url.toLowerCase();
  const { netloc, domain } = pyNetloc(url);
  if (/\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/.test(url)) {
    explanations.push({
      pattern: "ip_address",
      risk: "HIGH",
      explanation: "Using an IP address instead of a domain name is a common phishing tactic",
      evidence: "IP address found in URL"
    });
    riskIndicators.push("ip address");
  }
  if (url.includes("@")) {
    explanations.push({
      pattern: "at_symbol",
      risk: "HIGH",
      explanation: "The @ symbol can hide the real destination domain",
      evidence: "@ symbol found in URL"
    });
    riskIndicators.push("contains @ symbol");
  }
  if (url.length > 150) {
    explanations.push({
      pattern: "url_length",
      risk: "MEDIUM",
      explanation: "Very long URLs are used to obfuscate the true destination",
      evidence: `URL length: ${url.length} characters`
    });
    riskIndicators.push(`Long URL (${url.length} chars)`);
  } else if (url.length <= 150) {
    safeIndicators.push(`URL length: ${url.length}`);
  }
  if (/\.[a-z]{2,4}\.[a-z]{2,4}$/.test(lower)) {
    explanations.push({
      pattern: "double_extension",
      risk: "HIGH",
      explanation: "Double file extensions are often used to disguise executables",
      evidence: `Extension chain: ${lower.split(".").slice(-2).join(".")}`
    });
    riskIndicators.push("double extension");
  }
  if (SUSPICIOUS_TLDS.some((t) => lower.endsWith(t))) {
    const tld = url.split(".").pop() ?? "";
    explanations.push({
      pattern: "suspicious_tld",
      risk: "MEDIUM",
      explanation: "This top-level domain is frequently abused for phishing campaigns",
      evidence: `TLD: .${tld}`
    });
    riskIndicators.push(`Suspicious TLD: .${tld}`);
  }
  if (/%[0-9a-f]{2}/i.test(url)) {
    explanations.push({
      pattern: "encoded_chars",
      risk: "LOW",
      explanation: "Encoded characters can be used to bypass filters",
      evidence: "Percent-encoded characters found"
    });
  }
  const strippedDomain = domain.replace(/^secure\./, "").replace(/^login\./, "");
  const hasKeyword = /\b(secure|login|account|verify)\b/.test(domain) || /^secure\.|^login\.|^account\.|^verify\./.test(netloc);
  if (hasKeyword && !SAFE_DOMAINS.some((s) => domain.includes(s))) {
    explanations.push({
      pattern: "subdomain_abuse",
      risk: "HIGH",
      explanation: "Suspicious keywords in subdomain can impersonate legitimate sites",
      evidence: `Subdomain contains: ${strippedDomain}`
    });
    riskIndicators.push("Suspicious subdomain keywords");
  }
  if (url.startsWith("https")) safeIndicators.push("HTTPS encryption present");
  const parts = netloc.split(".");
  const mainDomain = parts.length > 1 ? parts[parts.length - 2] : netloc;
  if (ESTABLISHED_TLDS.includes(mainDomain)) {
    safeIndicators.push("Established TLD (.com, .org, etc.)");
  }
  if ((features == null ? void 0 : features.has_https) === false) riskIndicators.push("No HTTPS encryption");
  if (features == null ? void 0 : features.has_ip_address) riskIndicators.push("Contains IP address");
  if (((features == null ? void 0 : features.dash_count) ?? 0) > 3) riskIndicators.push(`Many dashes (${features == null ? void 0 : features.dash_count})`);
  if (features == null ? void 0 : features.suspicious_tld) riskIndicators.push("Suspicious top-level domain");
  return {
    prediction,
    explanations,
    risk_indicators: [...new Set(riskIndicators)],
    safe_indicators: [...new Set(safeIndicators)],
    summary: generateSummary(prediction, riskIndicators),
    security_tips: securityTips(prediction)
  };
}
function generateSummary(prediction, indicators) {
  const n = indicators.length;
  switch (prediction) {
    case "phishing":
      return `High-risk URL. Found ${n} phishing indicator${n === 1 ? "" : "s"}. Do not enter credentials on this page.`;
    case "suspicious":
      return `Found ${n} medium-risk pattern${n === 1 ? "" : "s"}. Exercise caution - this content has some phishing indicators.`;
    default:
      return indicators.length > 0 ? `No significant phishing patterns detected (${n} informational note${n === 1 ? "" : "s"}).` : "No phishing patterns detected. Standard browsing caution still applies.";
  }
}
function securityTips(prediction) {
  if (prediction === "phishing") {
    return [
      "Do not enter any personal information on this site",
      "Navigate to the official website by typing the address yourself",
      "Report this page to your browser or IT security team"
    ];
  }
  if (prediction === "suspicious") {
    return [
      "Check the main domain, not just the subdomain",
      "Always verify the sender or source before acting",
      "Never click links in suspicious emails"
    ];
  }
  return ["When in doubt, navigate directly to the website", "Keep your browser and password manager updated"];
}
const WEIGHTS = {
  ml_prediction: 0.35,
  threat_intel: 0.3,
  heuristics: 0.2,
  domain_reputation: 0.15
};
function calculateRiskScore(prediction, confidence, reasons = [], domainInfo = {}, urlIndicators = {}) {
  const mlScore = calculateMlScore(prediction, confidence);
  const tiScore = 0;
  const heuristicScore = calculateHeuristicScore(reasons);
  const domainScore = calculateDomainScore(domainInfo, urlIndicators);
  const riskScore = Math.trunc(
    mlScore * WEIGHTS.ml_prediction + tiScore * WEIGHTS.threat_intel + heuristicScore * WEIGHTS.heuristics + domainScore * WEIGHTS.domain_reputation
  );
  let riskLevel;
  let riskColor;
  if (riskScore >= 61) {
    riskLevel = "PHISHING";
    riskColor = "#ef4444";
  } else if (riskScore >= 31) {
    riskLevel = "SUSPICIOUS";
    riskColor = "#f59e0b";
  } else {
    riskLevel = "SAFE";
    riskColor = "#10b981";
  }
  return {
    risk_score: riskScore,
    risk_level: riskLevel,
    risk_color: riskColor,
    breakdown: {
      ml_score: mlScore,
      threat_intel_score: tiScore,
      heuristic_score: heuristicScore,
      domain_score: domainScore
    },
    recommendation: getRecommendation(riskLevel)
  };
}
function calculateMlScore(prediction, confidence) {
  if (prediction === "phishing") return Math.min(confidence * 100 + 20, 100) | 0;
  if (prediction === "suspicious") return confidence * 60 + 20 | 0;
  return (1 - confidence) * 30 | 0;
}
function calculateHeuristicScore(reasons) {
  const HIGH = ["contains @ symbol", "uses ip address", "very long url", "login page", "credential harvesting", "fake login"];
  const MEDIUM = ["no https", "suspicious tld", "unusual domain", "multiple redirects"];
  let score = 0;
  for (const reasonRaw of reasons) {
    const reason = reasonRaw.toLowerCase();
    let matched = false;
    for (const hr of HIGH) {
      if (reason.includes(hr)) {
        score += 15;
        matched = true;
        break;
      }
    }
    if (!matched) {
      for (const mr of MEDIUM) {
        if (reason.includes(mr)) {
          score += 8;
          break;
        }
      }
    }
  }
  return Math.min(score, 100);
}
function calculateDomainScore(domainInfo, urlIndicators) {
  var _a2, _b2;
  let score = 0;
  const ageDays = domainInfo.age_days;
  if (ageDays !== void 0 && ageDays !== null) {
    if (ageDays < 7) score += 30;
    else if (ageDays < 30) score += 15;
    else if (ageDays > 365) score -= 10;
  }
  score += (((_a2 = domainInfo.risk_factors) == null ? void 0 : _a2.length) ?? 0) * 8;
  score += Math.min(urlIndicators.risk_score ?? 0, 20);
  score += (((_b2 = urlIndicators.brand_mentions) == null ? void 0 : _b2.length) ?? 0) * 10;
  return Math.max(0, Math.min(score, 100));
}
function getRecommendation(riskLevel) {
  const recommendations = {
    PHISHING: [
      "DO NOT visit this URL",
      "DO NOT enter any personal information",
      "Report to your IT security team"
    ],
    SUSPICIOUS: [
      "Exercise caution before visiting",
      "Verify the sender through official channels",
      "Do not enter credentials unless you typed the address yourself"
    ],
    SAFE: [
      "No major red flags detected",
      "Always verify addresses before entering sensitive information"
    ]
  };
  return recommendations[riskLevel][0];
}
const TRUST_KEY = "pgai_trust_lists";
async function getLists() {
  try {
    const stored = await chrome.storage.local.get(TRUST_KEY);
    const lists = stored[TRUST_KEY];
    return {
      trusted: Array.isArray(lists == null ? void 0 : lists.trusted) ? lists.trusted : [],
      blocked: Array.isArray(lists == null ? void 0 : lists.blocked) ? lists.blocked : []
    };
  } catch {
    return { trusted: [], blocked: [] };
  }
}
async function saveLists(lists) {
  await chrome.storage.local.set({ [TRUST_KEY]: lists });
}
async function addTo(list2, rawDomain) {
  const domain = normalizeDomain(rawDomain);
  if (!domain) throw new Error("Invalid domain");
  const lists = await getLists();
  if (!lists[list2].includes(domain)) {
    lists[list2].push(domain);
    lists[list2].sort();
    await saveLists(lists);
  }
  return lists;
}
async function removeFrom(list2, rawDomain) {
  const domain = normalizeDomain(rawDomain);
  const lists = await getLists();
  lists[list2] = lists[list2].filter((d) => d !== domain);
  await saveLists(lists);
  return lists;
}
function normalizeDomain(input) {
  let value = (input || "").trim().toLowerCase();
  if (!value) return "";
  if (/^[a-z][a-z0-9+.-]*:\/\//.test(value)) {
    try {
      value = new URL(value).hostname;
    } catch {
      return "";
    }
  }
  value = value.split("/")[0].split("?")[0].split(":").pop() ?? "";
  if (!/^[a-z0-9.-]+\.[a-z]{2,}$/.test(value)) return "";
  return value;
}
function hostMatches(host, entry) {
  return host === entry || host.endsWith(`.${entry}`);
}
function hostnameOf(url) {
  const normalized = normalizeDomain(url);
  return normalized;
}
async function checkTrust(url) {
  const host = hostnameOf(url);
  if (!host) return "unlisted";
  const lists = await getLists();
  if (lists.blocked.some((d) => hostMatches(host, d))) return "blocked";
  if (lists.trusted.some((d) => hostMatches(host, d))) return "trusted";
  return "unlisted";
}
const KNOWN_GOOD_DOMAINS = [
  // Search / Google ecosystem
  "google.com",
  "youtube.com",
  "gmail.com",
  "blogger.com",
  // AI services
  "chatgpt.com",
  "openai.com",
  "claude.ai",
  "anthropic.com",
  "gemini.google.com",
  "perplexity.ai",
  "huggingface.co",
  // Dev platforms
  "github.com",
  "gitlab.com",
  "stackoverflow.com",
  "npmjs.com",
  "vercel.app",
  "netlify.app",
  "codepen.io",
  // Commerce / cloud
  "amazon.com",
  "aws.amazon.com",
  "azure.microsoft.com",
  "microsoft.com",
  "live.com",
  "office.com",
  "microsoftonline.com",
  "apple.com",
  "icloud.com",
  // Social / content
  "facebook.com",
  "instagram.com",
  "whatsapp.com",
  "x.com",
  "twitter.com",
  "reddit.com",
  "linkedin.com",
  "tiktok.com",
  "pinterest.com",
  "discord.com",
  "twitch.tv",
  "medium.com",
  "quora.com",
  // Media / productivity
  "netflix.com",
  "spotify.com",
  "primevideo.com",
  "hotstar.com",
  "notion.so",
  "dropbox.com",
  "zoom.us",
  "slack.com",
  "wikipedia.org",
  "archive.org",
  "mozilla.org",
  // Finance / commerce (exact infra only)
  "paypal.com",
  "ebay.com",
  "stripe.com",
  "razorpay.com",
  "coinbase.com",
  "binance.com"
];
function registeredHost(url) {
  try {
    return new URL(url).hostname.toLowerCase();
  } catch {
    let v = url.trim().toLowerCase();
    if (v.includes("://")) v = v.split("://")[1] ?? "";
    return v.split("/")[0].split("?")[0];
  }
}
function isKnownGoodDomain(url) {
  const host = registeredHost(url);
  if (!host || !host.includes(".")) return false;
  return KNOWN_GOOD_DOMAINS.some(
    (d) => host === d || host.endsWith(`.${d}`)
  );
}
const STATS_KEY = "pgai_stats";
const DAY_RETENTION = 35;
function emptyStats() {
  return {
    totalScans: 0,
    phishingBlocked: 0,
    suspiciousSeen: 0,
    safeVisits: 0,
    byDay: {},
    updatedAt: (/* @__PURE__ */ new Date()).toISOString()
  };
}
async function getStats() {
  try {
    const stored = await chrome.storage.local.get(STATS_KEY);
    return stored[STATS_KEY] ?? emptyStats();
  } catch {
    return emptyStats();
  }
}
async function recordVerdict(result) {
  if (result.source === "trust-list" && String(result.prediction) === "safe") return;
  const pred = String(result.prediction ?? "safe").toLowerCase();
  const score = Number(result.risk_score ?? 0);
  const isThreat = pred === "phishing" || score >= 65 || result.source === "trust-list" && pred !== "safe";
  const stats = await getStats();
  const today = dayKey(/* @__PURE__ */ new Date());
  stats.totalScans += 1;
  if (isThreat) stats.phishingBlocked += 1;
  else if (pred === "suspicious" || score >= 35) stats.suspiciousSeen += 1;
  else stats.safeVisits += 1;
  const day = stats.byDay[today] ?? { scans: 0, threats: 0 };
  day.scans += 1;
  if (isThreat) day.threats += 1;
  stats.byDay[today] = day;
  pruneOldDays(stats);
  stats.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
  try {
    await chrome.storage.local.set({ [STATS_KEY]: stats });
  } catch (error) {
    console.warn("[Stats] write failed:", error);
  }
}
async function resetStats() {
  const fresh = emptyStats();
  try {
    await chrome.storage.local.set({ [STATS_KEY]: fresh });
  } catch (error) {
    console.warn("[Stats] reset failed:", error);
  }
  return fresh;
}
function dayKey(d) {
  return d.toISOString().slice(0, 10);
}
function pruneOldDays(stats) {
  const cutoff = Date.now() - DAY_RETENTION * 864e5;
  for (const key of Object.keys(stats.byDay)) {
    if ((/* @__PURE__ */ new Date(`${key}T00:00:00Z`)).getTime() < cutoff) {
      delete stats.byDay[key];
    }
  }
}
const API_BASE_URL = DEFAULT_BASE_URL;
const SERVER_MODE_KEY = "pgai_server_mode";
async function initBackgroundAPIs() {
  console.log("[Background] Initializing local-first analysis engine");
  const ready = await isDbReady();
  try {
    const { loadModel: loadModel2 } = await __vitePreload(async () => {
      const { loadModel: loadModel3 } = await Promise.resolve().then(() => engine);
      return { loadModel: loadModel3 };
    }, true ? void 0 : void 0);
    await loadModel2();
    console.log("[Background] ONNX model loaded");
  } catch (error) {
    console.error("[Background] Model preload failed (will retry on demand):", error);
  }
  console.log("[Background] Background APIs initialized, dbReady:", ready);
  return ready;
}
async function isServerModeEnabled() {
  try {
    const stored = await chrome.storage.local.get(SERVER_MODE_KEY);
    return Boolean(stored[SERVER_MODE_KEY]);
  } catch {
    return false;
  }
}
async function analyzeURL(url) {
  console.log("[Background] Analyzing URL:", url);
  const trust = await checkTrust(url);
  if (trust === "blocked") {
    console.log("[Background] Blocked by user trust list");
    const blocked = trustOverrideResult(url, true);
    void recordVerdict(blocked);
    return blocked;
  }
  if (trust === "trusted") {
    console.log("[Background] Trusted by user trust list");
    return trustOverrideResult(url, false);
  }
  if (await isServerModeEnabled()) {
    try {
      const scanClient = new ScanApiClient(API_BASE_URL);
      const result2 = await scanClient.analyze(url);
      await cacheResult(url, result2);
      void recordVerdict(result2);
      console.log("[Background] Analysis via backend:", result2.prediction);
      return result2;
    } catch (error) {
      console.warn("[Background] Server analysis failed, using local engine:", error);
    }
  }
  const cached = await getCachedScan(url);
  if (cached) {
    console.log("[Background] Cached result");
    return cacheToScanResult(cached);
  }
  const result = await analyzeLocally(url);
  await cacheResult(url, result);
  void recordVerdict(result);
  console.log("[Background] Local analysis complete:", result.prediction);
  return result;
}
async function analyzeLocally(url) {
  const features = extractUrlFeatures(url);
  const featureFlags = {
    has_https: features[1] === 1,
    has_ip_address: features[3] === 1,
    dash_count: features[4],
    suspicious_tld: features[8] === 1
  };
  let { prediction, confidence } = await predictUrl(url);
  if (prediction !== "safe" && isKnownGoodDomain(url)) {
    console.log("[Background] Known-good brand domain, downgrading ML verdict");
    confidence = Math.max(0.9, 1 - confidence);
    prediction = "safe";
  }
  const explanation = explainUrl(url, prediction, featureFlags);
  const risk = calculateRiskScore(prediction, confidence, explanation.risk_indicators);
  const fusedPrediction = risk.risk_level === "PHISHING" ? "phishing" : risk.risk_level === "SUSPICIOUS" ? "suspicious" : "safe";
  return {
    session_id: `local-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`,
    url,
    prediction: fusedPrediction,
    confidence,
    risk_score: risk.risk_score,
    risk_level: risk.risk_level,
    risk_breakdown: risk.breakdown,
    reasons: explanation.risk_indicators,
    summary: explanation.summary,
    security_tips: explanation.security_tips,
    recommendation: risk.recommendation,
    analyzed_at: (/* @__PURE__ */ new Date()).toISOString(),
    source: "local"
  };
}
function cacheToScanResult(cached) {
  return {
    session_id: cached.session_id,
    url: cached.url,
    prediction: cached.prediction,
    confidence: cached.risk_score / 100,
    risk_score: cached.risk_score,
    risk_level: String(cached.prediction),
    summary: cached.summary,
    analyzed_at: new Date(cached.timestamp).toISOString(),
    isCached: true
  };
}
async function getCachedScan(url) {
  try {
    const cached = await get(url);
    if (cached) {
      return { ...cached, isCached: true };
    }
    return null;
  } catch (error) {
    console.error("[Background] Cache read failed:", error);
    return null;
  }
}
async function listRecentScans(limit = 5) {
  try {
    return await list(limit);
  } catch (error) {
    console.error("[Background] Cache list failed:", error);
    return [];
  }
}
function trustOverrideResult(url, blocked) {
  return {
    session_id: `trust-${Date.now().toString(36)}`,
    url,
    prediction: blocked ? "phishing" : "safe",
    confidence: 1,
    risk_score: blocked ? 100 : 0,
    risk_level: blocked ? "PHISHING" : "SAFE",
    risk_breakdown: { trust_list: blocked ? 100 : 0 },
    reasons: [blocked ? "Domain is on your block list" : "Domain is on your trusted list"],
    summary: blocked ? "You explicitly blocked this domain. PhishGuard will always flag it." : "You marked this domain as trusted. PhishGuard will not analyze it.",
    recommendation: blocked ? "Remove it from your block list in Settings if this was a mistake" : "",
    analyzed_at: (/* @__PURE__ */ new Date()).toISOString(),
    source: "trust-list"
  };
}
async function cacheResult(url, result) {
  try {
    await set(url, {
      session_id: result.session_id,
      url: result.url || url,
      risk_score: result.risk_score,
      prediction: result.prediction,
      summary: typeof result.summary === "string" ? result.summary : void 0
    });
    console.log("[Background] Result cached:", url);
  } catch (error) {
    console.error("[Background] Cache write failed:", error);
  }
}
async function clearAllCache() {
  try {
    await clear();
    console.log("[Background] Cache cleared");
  } catch (error) {
    console.error("[Background] Clear cache failed:", error);
  }
}
async function checkBackendHealth() {
  try {
    const metricsClient = new MetricsApiClient(API_BASE_URL);
    return await metricsClient.isBackendAvailable();
  } catch (error) {
    console.error("[Background] Health check failed:", error);
    return false;
  }
}
async function getTrustLists() {
  return getLists();
}
async function addTrustEntry(list2, domain) {
  return addTo(list2, domain);
}
async function removeTrustEntry(list2, domain) {
  return removeFrom(list2, domain);
}
function getVerdictStats() {
  return getStats();
}
function resetVerdictStats() {
  return resetStats();
}
let initialized = false;
async function initialize() {
  if (initialized) return;
  try {
    await initBackgroundAPIs();
    initialized = true;
    console.log("[Background] PhishGuard initialized");
  } catch (error) {
    console.error("[Background] Initialization error:", error);
  }
}
initialize();
const BADGE_SAFE = "#10b981";
const BADGE_SUSPICIOUS = "#f59e0b";
const BADGE_PHISHING = "#ef4444";
function updateTabBadge(tabId, result) {
  try {
    const score = Math.round(Number(result.risk_score ?? 0));
    const pred = String(result.prediction ?? "safe").toLowerCase();
    const color = pred === "phishing" || score >= 65 ? BADGE_PHISHING : pred === "suspicious" || score >= 35 ? BADGE_SUSPICIOUS : BADGE_SAFE;
    const text = color === BADGE_SAFE ? "" : String(Math.min(score, 999));
    chrome.action.setBadgeBackgroundColor({ tabId, color });
    chrome.action.setBadgeText({ tabId, text });
  } catch (error) {
    console.debug("[Background] Badge update skipped:", error);
  }
}
(_b = (_a = chrome.tabs) == null ? void 0 : _a.onRemoved) == null ? void 0 : _b.addListener((tabId) => {
  chrome.action.setBadgeText({ tabId, text: "" }).catch(() => {
  });
});
const MENU_SCAN_LINK = "pg-scan-link";
const MENU_SCAN_PAGE = "pg-scan-page";
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create(
    {
      id: MENU_SCAN_LINK,
      title: "🛡️ Scan this link with PhishGuard",
      contexts: ["link"]
    },
    () => void chrome.runtime.lastError
    // duplicate id on reload - safe to ignore
  );
  chrome.contextMenus.create(
    {
      id: MENU_SCAN_PAGE,
      title: "🛡️ Scan this page with PhishGuard",
      contexts: ["page", "frame"]
    },
    () => void chrome.runtime.lastError
  );
});
chrome.contextMenus.onClicked.addListener((info) => {
  const target = info.menuItemId === MENU_SCAN_LINK ? info.linkUrl : info.pageUrl;
  if (!target || !/^https?:/i.test(target)) return;
  console.log("[Background] Context-menu scan:", target);
  void analyzeURL(target).then((result) => notifyVerdict(target, result)).catch((error) => {
    console.error("[Background] Context scan failed:", error);
    notifyError(target, error instanceof Error ? error.message : "Analysis failed");
  });
});
function verdictTone(result) {
  const score = Math.round(Number(result.risk_score ?? 0));
  const pred = String(result.prediction ?? "safe").toLowerCase();
  if (pred === "phishing" || score >= 65) return "phishing";
  if (pred === "suspicious" || score >= 35) return "suspicious";
  return "safe";
}
function notifyVerdict(url, result) {
  const tone = verdictTone(result);
  const score = Math.round(Number(result.risk_score ?? 0));
  const titles = {
    phishing: `🛑 Dangerous link (risk ${score}/100)`,
    suspicious: `⚠️ Suspicious link (risk ${score}/100)`,
    safe: `✅ Link looks safe (risk ${score}/100)`
  };
  const detail = typeof result.summary === "string" && result.summary.length > 0 ? result.summary : url;
  chrome.notifications.create(
    {
      type: "basic",
      iconUrl: chrome.runtime.getURL("icons/icon-128.png"),
      title: titles[tone],
      message: `${url}
${detail}`.slice(0, 400),
      priority: tone === "phishing" ? 2 : 1
    },
    (notificationId) => {
      const onClicked = (id) => {
        if (id !== notificationId) return;
        chrome.notifications.onClicked.removeListener(onClicked);
        chrome.notifications.clear(notificationId, () => void chrome.runtime.lastError);
        chrome.tabs.create({
          url: `${chrome.runtime.getURL("src/popup/popup.html")}?url=${encodeURIComponent(url)}`
        });
      };
      chrome.notifications.onClicked.addListener(onClicked);
    }
  );
}
function notifyError(url, message) {
  chrome.notifications.create({
    type: "basic",
    iconUrl: chrome.runtime.getURL("icons/icon-128.png"),
    title: "🛡️ PhishGuard could not analyze that link",
    message: `${url}
${message}`.slice(0, 400)
  });
}
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  switch (message == null ? void 0 : message.action) {
    case "analyze": {
      const url = message.url;
      if (!url) {
        sendResponse({ success: false, error: "URL is required" });
        return;
      }
      analyzeURL(url).then((result) => {
        var _a2;
        if (((_a2 = sender.tab) == null ? void 0 : _a2.id) !== void 0) updateTabBadge(sender.tab.id, result);
        sendResponse({ success: true, data: result });
      }).catch((error) => {
        sendResponse({
          success: false,
          error: error instanceof Error ? error.message : "Analysis failed"
        });
      });
      return true;
    }
    case "health": {
      checkBackendHealth().then((healthy) => sendResponse({ success: true, healthy })).catch(() => sendResponse({ success: false, healthy: false }));
      return true;
    }
    case "recentScans": {
      listRecentScans(message.limit ?? 5).then((scans) => sendResponse({ success: true, data: scans })).catch(() => sendResponse({ success: true, data: [] }));
      return true;
    }
    case "clearCache": {
      clearAllCache().then(() => sendResponse({ success: true })).catch(() => sendResponse({ success: false }));
      return true;
    }
    case "trustGet": {
      getTrustLists().then((lists) => sendResponse({ success: true, data: lists })).catch(
        (error) => sendResponse({ success: false, error: error instanceof Error ? error.message : "failed" })
      );
      return true;
    }
    case "trustAdd": {
      addTrustEntry(message.list, message.domain).then((lists) => sendResponse({ success: true, data: lists })).catch(
        (error) => sendResponse({ success: false, error: error instanceof Error ? error.message : "failed" })
      );
      return true;
    }
    case "trustRemove": {
      removeTrustEntry(message.list, message.domain).then((lists) => sendResponse({ success: true, data: lists })).catch(
        (error) => sendResponse({ success: false, error: error instanceof Error ? error.message : "failed" })
      );
      return true;
    }
    case "statsGet": {
      getVerdictStats().then((stats) => sendResponse({ success: true, data: stats })).catch(() => sendResponse({ success: false }));
      return true;
    }
    case "scanMessage": {
      const text = message.text;
      if (!text || !text.trim()) {
        sendResponse({ success: false, error: "Message text is required" });
        return;
      }
      __vitePreload(async () => {
        const { scanMessage } = await import("./textDetector.js");
        return { scanMessage };
      }, true ? __vite__mapDeps([0,1,2]) : void 0).then(({ scanMessage }) => scanMessage(text)).then((result) => {
        void recordVerdict(result);
        sendResponse({ success: true, data: result });
      }).catch(
        (error) => sendResponse({
          success: false,
          error: error instanceof Error ? error.message : "Message scan failed"
        })
      );
      return true;
    }
    case "statsReset": {
      resetVerdictStats().then((stats) => sendResponse({ success: true, data: stats })).catch(() => sendResponse({ success: false }));
      return true;
    }
    default:
      return void 0;
  }
});
export {
  predictUrl as p
};
//# sourceMappingURL=background.js.map
