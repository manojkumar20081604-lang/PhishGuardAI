import { B as BaseApiClient } from "./cache.js";
class MetricsApiClient extends BaseApiClient {
  constructor(baseUrl) {
    super(baseUrl);
  }
  /**
   * Get dashboard overview metrics
   */
  async getOverview() {
    console.log("[MetricsAPI] Fetching overview metrics");
    return this.requestWithRetry(
      "/api/v1/metrics/overview",
      { method: "GET" }
    );
  }
  /**
   * Check system health (backend availability, response time)
   */
  async getSystemHealth() {
    console.log("[MetricsAPI] Checking system health");
    return this.requestWithRetry(
      "/api/v1/metrics/system/health",
      { method: "GET" }
    );
  }
  /**
   * Quick health check (boolean) - for lightweight availability checks
   */
  async isBackendAvailable() {
    try {
      await this.requestWithRetry("/api/v1/metrics/system/health", { method: "GET" }, { maxRetries: 0 });
      return true;
    } catch {
      return false;
    }
  }
}
export {
  MetricsApiClient as M
};
//# sourceMappingURL=metricsApi.js.map
