import "./modulepreload-polyfill.js";
import { c as clear, g as get, n as normalizePrediction, l as list } from "./cache.js";
function buildScanReportPdf(result) {
  const lines = layoutReport(result);
  return assemblePdf(lines);
}
function downloadScanReport(result) {
  const bytes = buildScanReportPdf(result);
  const blob = new Blob([bytes], { type: "application/pdf" });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = `phishguard-report-${stamp()}.pdf`;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1e4);
}
function stamp() {
  return (/* @__PURE__ */ new Date()).toISOString().slice(0, 19).replace(/[:T]/g, "-");
}
const PAGE_W = 595;
const PAGE_H = 842;
const MARGIN = 48;
const TEXT_W = PAGE_W - MARGIN * 2;
const INK = { r: 0.18, g: 0.22, b: 0.28 };
const MUTED = { r: 0.44, g: 0.5, b: 0.59 };
const LINE_GRAY = { r: 0.89, g: 0.91, b: 0.94 };
function verdictTheme(prediction) {
  switch (String(prediction).toLowerCase()) {
    case "phishing":
      return { label: "PHISHING", color: { r: 0.9, g: 0.24, b: 0.24 } };
    case "suspicious":
      return { label: "SUSPICIOUS", color: { r: 0.85, g: 0.55, b: 0.12 } };
    default:
      return { label: "SAFE", color: { r: 0.13, g: 0.62, b: 0.59 } };
  }
}
const AVG_CHAR = 0.52;
function wrap(text, size, maxWidthPt) {
  const maxChars = Math.max(8, Math.floor(maxWidthPt / (size * AVG_CHAR)));
  const words = text.split(/\s+/).filter(Boolean);
  const out = [];
  let current = "";
  for (const word of words) {
    let w = word;
    while (w.length > maxChars) {
      if (current) {
        out.push(current);
        current = "";
      }
      out.push(w.slice(0, maxChars));
      w = w.slice(maxChars);
    }
    if (!current) {
      current = w;
    } else if ((current + " " + w).length <= maxChars) {
      current += " " + w;
    } else {
      out.push(current);
      current = w;
    }
  }
  if (current) out.push(current);
  return out.length > 0 ? out : [""];
}
function layoutReport(result) {
  const theme = verdictTheme(result.prediction);
  const score = Math.round(Number(result.risk_score ?? 0));
  const confidence = Math.round(Number(result.confidence ?? 0) * 100);
  const reasons = Array.isArray(result.reasons) ? result.reasons.filter(Boolean) : [];
  const tips = Array.isArray(result.security_tips) ? result.security_tips.filter(Boolean) : [];
  const summary = typeof result.summary === "string" ? result.summary.trim() : "";
  const subjectLabel = /^(📧|📱)/.test(result.url || "") ? "Analyzed Message" : result.url ? "Analyzed URL" : "Subject";
  const metaRows = [
    [subjectLabel, result.url || "-"],
    ["Verdict", theme.label],
    ["Risk Score", `${score} / 100`],
    ["Confidence", `${confidence}%`],
    ["Analyzed At", formatWhen(result.analyzed_at)]
  ];
  const page = [];
  page.push({ text: "PhishGuard AI", size: 22, bold: true, gapBefore: 14 });
  page.push({ text: "Scan Report", size: 13, bold: false, color: MUTED });
  page.push({ text: `Verdict: ${theme.label}`, size: 16, bold: true, color: theme.color, gapBefore: 18 });
  for (const [key, value] of metaRows) {
    const indent = key === subjectLabel ? 0 : 110;
    for (const [i, piece] of wrap(value, 10, TEXT_W - indent).entries()) {
      page.push({
        text: i === 0 && key !== subjectLabel ? `${padKey(key)}${piece}` : `           ${piece}`,
        size: 10,
        bold: false,
        color: key === "Verdict" && i === 0 ? theme.color : INK,
        gapBefore: i === 0 ? 6 : 1
      });
    }
  }
  const section = (title, items) => {
    const body = items.length > 0 ? items : ["-"];
    page.push({ text: title.toUpperCase(), size: 11, bold: true, color: MUTED, gapBefore: 16 });
    for (const item of body) {
      for (const [i, piece] of wrap(item, 10, TEXT_W - 14).entries()) {
        page.push({ text: `${i === 0 ? "• " : "  "}${piece}`, size: 10, bold: false, color: INK, gapBefore: i === 0 ? 4 : 2 });
      }
    }
  };
  section("Summary", summary ? [summary] : []);
  section("Risk Factors", reasons);
  section("Security Tips", tips);
  page.push({ text: "", size: 9, bold: false, gapBefore: 20 });
  page.push({
    text: "Generated locally by PhishGuard AI v3.1 - this analysis never left your device.",
    size: 9,
    bold: false,
    color: MUTED
  });
  const pages = [];
  let currentPage = [];
  let yCursor = MARGIN;
  for (const line of page) {
    const lead = line.size * 1.45;
    const need = (line.gapBefore ?? 0) + lead;
    if (yCursor + need > PAGE_H - MARGIN && currentPage.length > 0) {
      pages.push(currentPage);
      currentPage = [];
      yCursor = MARGIN;
    }
    currentPage.push(line);
    yCursor += need;
  }
  if (currentPage.length > 0) pages.push(currentPage);
  return pages.length > 0 ? pages : [[]];
}
function padKey(key) {
  return key.padEnd(12, " ");
}
function formatWhen(iso) {
  if (!iso) return "-";
  const d = new Date(iso);
  return Number.isNaN(d.getTime()) ? String(iso) : d.toLocaleString("en-GB", { hour12: false });
}
function pdfEscape(text) {
  const mapped = text.replace(/[•▪‣]/g, "-").replace(/[–—]/g, "-").replace(/[''`]/g, "'").replace(/[""]/g, '"').replace(/…/g, "...");
  const latin1 = mapped.replace(/[^\x20-\x7E\xA0-\xFF]/g, "");
  return latin1.replace(/\\/g, "\\\\").replace(/\(/g, "\\(").replace(/\)/g, "\\)");
}
function rgb(color) {
  const c = color ?? INK;
  return `${c.r.toFixed(3)} ${c.g.toFixed(3)} ${c.b.toFixed(3)} rg`;
}
function contentStreamFor(pages) {
  return pages.map((lines) => {
    const parts = [];
    let y = PAGE_H - MARGIN;
    for (const line of lines) {
      y -= (line.gapBefore ?? 0) + line.size * 1.15;
      if (line.text.trim().length === 0) continue;
      const font = line.bold ? "/F2" : "/F1";
      parts.push(
        "BT",
        `${font} ${line.size} Tf`,
        rgb(line.color),
        `1 0 0 1 ${MARGIN} ${y.toFixed(2)} Tm`,
        `(${pdfEscape(line.text)}) Tj`,
        "ET"
      );
    }
    parts.push(
      rgb(LINE_GRAY),
      `${MARGIN} ${PAGE_H - MARGIN - 34} ${TEXT_W} 0.8 re f`
    );
    return parts.join("\n");
  });
}
function assemblePdf(pagesOfLines) {
  const streams = contentStreamFor(pagesOfLines);
  const pageCount = Math.max(1, streams.length);
  const objects = [];
  const add = (body) => {
    objects.push(body);
    return objects.length;
  };
  const fontRegular = add("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>");
  const fontBold = add("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>");
  const pageNums = [];
  for (let i = 0; i < pageCount; i++) {
    const stream = streams[i] ?? "BT ET";
    const contentsNum = add(`<< /Length ${byteLength(stream)} >>
stream
${stream}
endstream`);
    pageNums.push(
      add(
        `<< /Type /Page /Parent %PAGES% /MediaBox [0 0 ${PAGE_W} ${PAGE_H}] /Resources << /Font << /F1 ${fontRegular} 0 R /F2 ${fontBold} 0 R >> >> /Contents ${contentsNum} 0 R >>`
      )
    );
  }
  const kids = pageNums.map((n) => `${n} 0 R`).join(" ");
  const pagesPlaceholder = objects.length + 1;
  for (let i = 0; i < pageNums.length; i++) {
    const target = pageNums[i];
    objects[target - 1] = objects[target - 1].replace("%PAGES%", String(pagesPlaceholder));
  }
  const pagesObjNum = add(`<< /Type /Pages /Kids [${kids}] /Count ${pageCount} >>`);
  if (pagesObjNum !== pagesPlaceholder) throw new Error("PDF layout invariant broken");
  const catalogNum = add(`<< /Type /Catalog /Pages ${pagesObjNum} 0 R >>`);
  let pdf = "%PDF-1.4\n";
  const offsets = [];
  objects.forEach((body, index) => {
    offsets.push(byteLength(pdf));
    pdf += `${index + 1} 0 obj
${body}
endobj
`;
  });
  const xrefStart = byteLength(pdf);
  pdf += `xref
0 ${objects.length + 1}
`;
  pdf += "0000000000 65535 f \n";
  for (const offset of offsets) {
    pdf += `${String(offset).padStart(10, "0")} 00000 n 
`;
  }
  pdf += `trailer
<< /Size ${objects.length + 1} /Root ${catalogNum} 0 R >>
startxref
${xrefStart}
%%EOF`;
  return latin1Bytes(pdf);
}
function byteLength(text) {
  return text.length;
}
function latin1Bytes(text) {
  const bytes = new Uint8Array(text.length);
  for (let i = 0; i < text.length; i++) {
    bytes[i] = text.charCodeAt(i) & 255;
  }
  return bytes;
}
const $ = (id) => document.getElementById(id);
const elements = {
  scanView: $("scan-view"),
  urlInput: $("url-input"),
  scanBtn: $("scan-btn"),
  loadingContainer: $("loading-container"),
  errorContainer: $("error-container"),
  errorMessage: $("error-message"),
  retryBtn: $("retry-btn"),
  resultContainer: $("result-container"),
  resultUrl: $("result-url"),
  riskScore: $("risk-score"),
  riskLevelContainer: $("risk-level-container"),
  riskLevelText: $("risk-level-text"),
  explanationSection: $("explanation-section"),
  riskExplanation: $("risk-explanation"),
  rescanBtn: $("rescan-btn"),
  detailsBtn: $("details-btn"),
  reportBtn: $("report-btn"),
  historyBtn: $("history-btn"),
  historyContainer: $("history-container"),
  clearHistoryBtn: $("clear-history-btn"),
  scanHistoryList: $("scan-history-list"),
  backToScanBtn: $("back-to-scan-btn"),
  closeHistoryBtn: $("close-history-btn"),
  modalOverlay: $("modal-overlay"),
  modalTitle: $("modal-title"),
  modalCloseBtn: $("modal-close-btn"),
  modalBody: $("modal-body")
};
let lastResult = null;
let currentUrl = null;
const show = (el) => el.classList.remove("hidden");
const hide = (el) => el.classList.add("hidden");
function hideAllViews() {
  [
    elements.scanView,
    elements.loadingContainer,
    elements.errorContainer,
    elements.resultContainer,
    elements.historyContainer
  ].forEach(hide);
}
function showScanView() {
  hideAllViews();
  show(elements.scanView);
}
function showLoading() {
  hideAllViews();
  show(elements.loadingContainer);
}
function showError(message) {
  hideAllViews();
  elements.errorMessage.textContent = message;
  show(elements.errorContainer);
}
function showHistory() {
  hideAllViews();
  renderHistory();
  show(elements.historyContainer);
}
function riskClassFor(score) {
  if (score >= 65) return "danger";
  if (score >= 35) return "warning";
  return "safe";
}
function labelFor(prediction) {
  switch (normalizePrediction(prediction)) {
    case "phishing":
      return "Phishing";
    case "suspicious":
      return "Suspicious";
    default:
      return "Safe";
  }
}
function renderResult(result, opts = {}) {
  lastResult = result;
  hideAllViews();
  show(elements.resultContainer);
  const score = Math.round(Number(result.risk_score ?? 0));
  const cls = riskClassFor(score);
  elements.resultUrl.textContent = result.url || currentUrl || "";
  elements.riskScore.textContent = String(score);
  elements.riskLevelContainer.className = `risk-level ${cls}`;
  elements.riskLevelText.textContent = `${labelFor(result.prediction)}${opts.isCached ? " (cached)" : ""}`;
  const summary = firstString(result.summary);
  const reasons = Array.isArray(result.reasons) ? result.reasons.filter(Boolean) : [];
  if (summary || reasons.length > 0) {
    show(elements.explanationSection);
    elements.riskExplanation.innerHTML = escapeHtml(
      summary || reasons.join(" · ")
    );
  } else {
    hide(elements.explanationSection);
  }
}
function firstString(value) {
  return typeof value === "string" && value.trim().length > 0 ? value : "";
}
function escapeHtml(text) {
  return text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
async function scanUrl(url, opts = {}) {
  currentUrl = url;
  if (opts.cachedFirst && !opts.force) {
    const cached = await getFromCache(url);
    if (cached) {
      renderResult(cacheToScanResult(cached), { isCached: true });
      void analyzeAndRender(url);
      return;
    }
  }
  showLoading();
  await analyzeAndRender(url);
}
async function analyzeAndRender(url) {
  try {
    const response = await chrome.runtime.sendMessage({ action: "analyze", url });
    if (!(response == null ? void 0 : response.success)) {
      throw new Error((response == null ? void 0 : response.error) || "Analysis failed");
    }
    renderResult(response.data);
  } catch (error) {
    const cached = await getFromCache(url);
    if (cached) {
      console.log("[Popup] Engine unavailable, using cached result");
      renderResult(cacheToScanResult(cached), { isCached: true });
      return;
    }
    showError(
      error instanceof Error ? error.message : "Analysis failed."
    );
  }
}
async function getFromCache(url) {
  try {
    return await get(url);
  } catch {
    return null;
  }
}
function cacheToScanResult(cached) {
  return {
    session_id: cached.session_id,
    url: cached.url,
    prediction: cached.prediction,
    confidence: cached.risk_score / 100,
    risk_score: cached.risk_score,
    risk_level: cached.prediction,
    summary: cached.summary,
    analyzed_at: new Date(cached.timestamp).toISOString()
  };
}
async function getActiveTabUrl() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    return (tab == null ? void 0 : tab.url) ?? null;
  } catch {
    return null;
  }
}
async function renderHistory() {
  let scans = [];
  try {
    scans = await list(5);
  } catch (error) {
    console.warn("[Popup] History read failed:", error);
  }
  elements.scanHistoryList.innerHTML = "";
  if (scans.length === 0) {
    const li = document.createElement("li");
    li.className = "empty-state";
    li.textContent = "No recent scans yet.";
    elements.scanHistoryList.appendChild(li);
    return;
  }
  for (const scan of scans) {
    const li = document.createElement("li");
    li.className = `scan-item ${riskClassFor(scan.risk_score)}`;
    li.innerHTML = `
      <span class="scan-url">${escapeHtml(scan.url)}</span>
      <span class="scan-score ${riskClassFor(scan.risk_score)}">${Math.round(scan.risk_score)}</span>
    `;
    li.addEventListener("click", () => void scanUrl(scan.url, { force: true }));
    elements.scanHistoryList.appendChild(li);
  }
}
function openDetailsModal() {
  if (!lastResult) return;
  elements.modalTitle.textContent = "Analysis Details";
  const rows = [
    ["URL", lastResult.url || "-"],
    ["Prediction", labelFor(lastResult.prediction)],
    ["Risk Score", `${Math.round(Number(lastResult.risk_score ?? 0))}/100`],
    ["Confidence", `${Math.round(Number(lastResult.confidence ?? 0) * 100)}%`],
    ["Analyzed At", lastResult.analyzed_at ? new Date(lastResult.analyzed_at).toLocaleString() : "-"]
  ];
  const breakdownEntries = Object.entries(lastResult.risk_breakdown ?? {});
  const reasons = Array.isArray(lastResult.reasons) ? lastResult.reasons.filter(Boolean) : [];
  const tips = Array.isArray(lastResult.security_tips) ? lastResult.security_tips.filter(Boolean) : [];
  const section = (title, items) => items.length === 0 ? "" : `<h3>${escapeHtml(title)}</h3><ul>${items.map((i) => `<li>${escapeHtml(i)}</li>`).join("")}</ul>`;
  elements.modalBody.innerHTML = `
    <table class="details-table">
      ${rows.map(([k, v]) => `<tr><td><strong>${escapeHtml(k)}</strong></td><td>${escapeHtml(v)}</td></tr>`).join("")}
    </table>
    ${section("Risk Factors", reasons)}
    ${section("Security Tips", tips)}
    ${breakdownEntries.length === 0 ? "" : `
      <h3>Risk Breakdown</h3>
      <table class="details-table">
        ${breakdownEntries.map(([k, v]) => `<tr><td><strong>${escapeHtml(k)}</strong></td><td>${escapeHtml(String(v))}</td></tr>`).join("")}
      </table>
    `}
  `;
  show(elements.modalOverlay);
}
function closeModal() {
  hide(elements.modalOverlay);
}
function wireEvents() {
  wireUrlScanEvents();
  wireMessageScanEvents();
  wireResultButtons();
}
function wireUrlScanEvents() {
  elements.scanBtn.addEventListener("click", () => {
    const url = elements.urlInput.value.trim();
    if (!url || !url.includes(".")) {
      showError("Please enter a valid URL including the domain.");
      return;
    }
    void scanUrl(url, { force: true });
  });
  elements.retryBtn.addEventListener("click", () => {
    if (currentUrl) void scanUrl(currentUrl, { force: true });
    else showScanView();
  });
  elements.rescanBtn.addEventListener("click", () => {
    if (currentUrl) void scanUrl(currentUrl, { force: true });
  });
  elements.detailsBtn.addEventListener("click", openDetailsModal);
  elements.reportBtn.addEventListener("click", () => {
    if (lastResult) downloadScanReport(lastResult);
  });
  elements.modalCloseBtn.addEventListener("click", closeModal);
  elements.modalOverlay.addEventListener("click", (event) => {
    if (event.target === elements.modalOverlay) closeModal();
  });
}
function wireMessageScanEvents() {
  const tabUrl = document.getElementById("tab-url");
  const tabMsg = document.getElementById("tab-message");
  const urlControls = document.getElementById("url-scan-controls");
  const msgControls = document.getElementById("message-scan-controls");
  const urlHint = document.getElementById("url-mode-hint");
  const msgInput = document.getElementById("msg-input");
  const typeHint = document.getElementById("msg-type-hint");
  const openTabBtn = document.getElementById("open-tab-btn");
  openTabBtn == null ? void 0 : openTabBtn.addEventListener("click", () => {
    void chrome.tabs.create({
      url: `${location.href.split("?")[0]}?asPage=1&tab=message`
    });
    window.close();
  });
  function selectTab(which) {
    tabUrl.classList.toggle("active", which === "url");
    tabMsg.classList.toggle("active", which === "message");
    urlControls.classList.toggle("hidden", which !== "url");
    msgControls.classList.toggle("hidden", which === "url");
    urlHint.classList.toggle("hidden", which === "url");
  }
  selectTab("url");
  tabUrl.addEventListener("click", () => selectTab("url"));
  tabMsg.addEventListener("click", () => selectTab("message"));
  msgInput.addEventListener("input", () => {
    const text = msgInput.value.trim();
    if (!text) {
      typeHint.textContent = "Detected: —";
      return;
    }
    const isEmail = /^from:|^subject:/im.test(text) || /[\w.-]+@[\w.-]+\.\w+/.test(text) && text.length > 200;
    const chars = msgInput.value.length.toLocaleString();
    typeHint.textContent = `Detected: ${isEmail ? "📧 Email" : "📱 SMS/text"} · ${chars} characters (full text is analyzed)`;
  });
  document.getElementById("msg-scan-btn").addEventListener("click", () => void scanMessageFlow());
}
async function scanMessageFlow() {
  const input = document.getElementById("msg-input");
  const text = input.value.trim();
  if (!text) {
    showError("Paste an email or SMS message to analyze.");
    return;
  }
  showLoading();
  try {
    const response = await chrome.runtime.sendMessage({ action: "scanMessage", text });
    if (!(response == null ? void 0 : response.success)) {
      throw new Error((response == null ? void 0 : response.error) || "Message scan failed");
    }
    renderResult(messageToScanResult(response.data));
  } catch (error) {
    showError(error instanceof Error ? error.message : "Message scan failed.");
  }
}
function messageToScanResult(msg) {
  const firstLine = document.getElementById("msg-input").value.trim().split("\n")[0] ?? "";
  return {
    session_id: `msg-${Date.now().toString(36)}`,
    url: `${msg.detected_type === "email" ? "📧 Email" : "📱 SMS"} · ${firstLine.slice(0, 64)}${firstLine.length > 64 ? "…" : ""}`,
    prediction: msg.prediction,
    confidence: msg.confidence,
    risk_score: msg.risk_score,
    risk_level: String(msg.prediction).toUpperCase(),
    reasons: msg.reasons,
    summary: msg.summary,
    security_tips: msg.security_tips,
    analyzed_at: (/* @__PURE__ */ new Date()).toISOString()
  };
}
function wireResultButtons() {
  elements.historyBtn.addEventListener("click", () => void showHistory());
  elements.backToScanBtn.addEventListener("click", showScanView);
  elements.closeHistoryBtn.addEventListener("click", async () => {
    try {
      await clear();
      console.log("[Popup] History cleared");
    } catch (error) {
      console.warn("[Popup] Clear history failed:", error);
    }
    showScanView();
  });
}
async function init() {
  var _a, _b, _c;
  const params = new URLSearchParams(location.search);
  if (params.get("asPage") === "1") {
    document.body.classList.add("as-page");
    (_a = document.getElementById("open-tab-btn")) == null ? void 0 : _a.classList.add("hidden");
  }
  wireEvents();
  void loadStatsStrip();
  const preset = params.get("url");
  if (preset && /^https?:/i.test(preset)) {
    await scanUrl(preset, { cachedFirst: true });
    return;
  }
  if (params.get("tab") === "message") {
    showScanView();
    (_b = document.getElementById("tab-message")) == null ? void 0 : _b.click();
    (_c = document.querySelector("#msg-input")) == null ? void 0 : _c.focus();
    return;
  }
  const tabUrl = await getActiveTabUrl();
  if (tabUrl && /^https?:/i.test(tabUrl)) {
    await scanUrl(tabUrl, { cachedFirst: true });
  } else {
    showScanView();
  }
}
document.addEventListener("DOMContentLoaded", () => {
  void init();
});
async function loadStatsStrip() {
  var _a, _b;
  try {
    const response = await chrome.runtime.sendMessage({ action: "statsGet" });
    if (!(response == null ? void 0 : response.success)) return;
    const stats = response.data;
    let weekThreats = 0;
    for (let i = 0; i < 7; i++) {
      const key = new Date(Date.now() - i * 864e5).toISOString().slice(0, 10);
      weekThreats += ((_b = (_a = stats.byDay) == null ? void 0 : _a[key]) == null ? void 0 : _b.threats) ?? 0;
    }
    const strip = document.getElementById("stats-strip");
    const threatsEl = document.getElementById("stats-threats-week");
    const totalEl = document.getElementById("stats-scans-total");
    if (strip && threatsEl && totalEl) {
      threatsEl.textContent = String(weekThreats);
      totalEl.textContent = String(stats.totalScans ?? 0);
      strip.classList.remove("hidden");
    }
  } catch {
  }
}
//# sourceMappingURL=popup.js.map
