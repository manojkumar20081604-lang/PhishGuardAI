const DEFAULT_BASE_URL = "http://localhost:5000";
const DEFAULT_TIMEOUT_MS = 1e4;
const DEFAULT_MAX_RETRIES = 3;
const RETRY_DELAYS_MS = [1e3, 2e3, 4e3];
class BaseAPIError extends Error {
  constructor(message, code, retryAfterSeconds, originalError) {
    super(message);
    this.code = code;
    this.retryAfterSeconds = retryAfterSeconds;
    this.originalError = originalError;
    this.name = "BaseAPIError";
  }
}
class RateLimitError extends BaseAPIError {
  constructor(retryAfterSeconds) {
    super(
      `Rate limit exceeded, retry in ${retryAfterSeconds} seconds`,
      "RATE_LIMITED",
      retryAfterSeconds
    );
    this.name = "RateLimitError";
  }
}
class NotFoundError extends BaseAPIError {
  constructor(message = "Resource not found") {
    super(message, "NOT_FOUND");
    this.name = "NotFoundError";
  }
}
class ServerError extends BaseAPIError {
  constructor(message = "Backend error, try again later") {
    super(message, "SERVER_ERROR");
    this.name = "ServerError";
  }
}
class BackendUnavailableError extends BaseAPIError {
  constructor(originalError) {
    super("Backend service is temporarily unavailable", "BACKEND_UNAVAILABLE", void 0, originalError);
    this.name = "BackendUnavailableError";
  }
}
class ParseError extends BaseAPIError {
  constructor(message) {
    super(`Failed to parse response: ${message}`, "PARSE_ERROR");
    this.name = "ParseError";
  }
}
function mapHttpError(status, body) {
  switch (status) {
    case 429: {
      return new RateLimitError(60);
    }
    case 404:
      return new NotFoundError(body || void 0);
    case 500:
    case 502:
    case 503:
    case 504:
      return new ServerError(body || void 0);
    default:
      return new BaseAPIError(`HTTP ${status}: ${body || "Unknown error"}`, `HTTP_${status}`);
  }
}
class BaseApiClient {
  constructor(baseUrl = DEFAULT_BASE_URL) {
    this.baseUrl = baseUrl.replace(/\/+$/, "");
  }
  /**
   * Perform a request with timeout + exponential backoff retries.
   * Retries on network failures and 5xx responses (not on 4xx).
   */
  async requestWithRetry(endpoint, options = {}, {
    timeoutMs = DEFAULT_TIMEOUT_MS,
    maxRetries = DEFAULT_MAX_RETRIES
  } = {}) {
    let lastError;
    for (let attempt = 0; attempt <= maxRetries; attempt++) {
      if (attempt > 0) {
        const delay = RETRY_DELAYS_MS[Math.min(attempt - 1, RETRY_DELAYS_MS.length - 1)];
        await sleep(delay);
        console.log(`[BaseAPI] Retry attempt ${attempt}/${maxRetries} for ${endpoint}`);
      }
      try {
        return await this.requestOnce(endpoint, options, timeoutMs);
      } catch (error) {
        lastError = error;
        if (error instanceof BaseAPIError && !(error instanceof ServerError)) {
          throw error;
        }
      }
    }
    throw lastError;
  }
  async requestOnce(endpoint, options, timeoutMs) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    let response;
    try {
      response = await fetch(`${this.baseUrl}${endpoint}`, {
        ...options,
        signal: controller.signal
      });
    } catch (error) {
      throw new BackendUnavailableError(error);
    } finally {
      clearTimeout(timer);
    }
    if (!response.ok) {
      if (response.status === 429) {
        const retryAfter = Number(response.headers.get("Retry-After")) || 60;
        throw new RateLimitError(retryAfter);
      }
      const body = await safeReadBody(response);
      throw mapHttpError(response.status, body ?? void 0);
    }
    try {
      return await response.json();
    } catch (error) {
      throw new ParseError("Response is not valid JSON");
    }
  }
  async get(endpoint) {
    return this.requestWithRetry(endpoint, { method: "GET" });
  }
  async post(endpoint, body) {
    return this.requestWithRetry(endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: body !== void 0 ? JSON.stringify(body) : void 0
    });
  }
}
async function safeReadBody(response) {
  try {
    return await response.text();
  } catch {
    return null;
  }
}
function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
class ScanApiClient extends BaseApiClient {
  /**
   * Analyze a URL for phishing risk.
   */
  async analyze(url) {
    const raw = await this.post("/api/v1/analyze/url", { url });
    return normalizeAnalyzeResponse(raw);
  }
  /**
   * Fetch a previously stored scan result by session ID.
   * Note: user-scoped scan history is deferred until auth is implemented.
   */
  async getBySession(sessionId) {
    const raw = await this.get(
      `/api/v1/scans/${encodeURIComponent(sessionId)}`
    );
    return {
      session_id: raw.session_id,
      url: raw.input_url ?? "",
      prediction: normalizePrediction(raw.risk_level),
      confidence: raw.risk_score,
      risk_score: Math.round((raw.risk_score ?? 0) * 100) / 100,
      risk_level: raw.risk_level,
      summary: raw.explanation_text ?? void 0,
      features: raw.features_json,
      analyzed_at: raw.created_at ?? (/* @__PURE__ */ new Date()).toISOString()
    };
  }
}
function normalizeAnalyzeResponse(raw) {
  return {
    session_id: raw.session_id,
    analysis_id: raw.analysis_id,
    url: raw.url,
    prediction: normalizePrediction(raw.prediction),
    confidence: raw.confidence,
    risk_score: raw.risk_score,
    risk_level: raw.risk_level,
    risk_breakdown: raw.risk_breakdown,
    reasons: raw.reasons,
    summary: raw.summary,
    security_tips: raw.security_tips,
    recommendation: raw.recommendation,
    analyzed_at: raw.analyzed_at
  };
}
function normalizePrediction(value) {
  const v = String(value || "").toLowerCase();
  if (v.includes("phish") || v.includes("critical") || v.includes("high")) return "phishing";
  if (v.includes("suspicious") || v.includes("medium")) return "suspicious";
  return "safe";
}
new ScanApiClient();
const DB_NAME = "PhishGuardDB";
const DB_VERSION = 1;
const STORE_NAME = "scanCache";
const MAX_CACHE_SIZE = 50;
let db = null;
async function initDb() {
  if (db) return db;
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = (event) => {
      const database = event.target.result;
      if (!database.objectStoreNames.contains(STORE_NAME)) {
        const store = database.createObjectStore(STORE_NAME, { keyPath: "session_id" });
        store.createIndex("url", "url", { unique: false });
        store.createIndex("timestamp", "timestamp", { unique: false });
      }
    };
    request.onerror = () => reject(request.error);
    request.onsuccess = () => {
      db = request.result;
      db.onclose = () => {
        db = null;
      };
      console.log("[CacheDB] Database ready");
      resolve(db);
    };
  });
}
async function getStore(mode) {
  const database = await initDb();
  return database.transaction([STORE_NAME], mode).objectStore(STORE_NAME);
}
async function set(url, result) {
  const store = await getStore("readwrite");
  const entry = {
    session_id: result.session_id || generateSessionId(url),
    url,
    risk_score: result.risk_score ?? 0,
    prediction: result.prediction ?? "safe",
    summary: result.summary,
    timestamp: Date.now(),
    model_version: result.model_version,
    confidence: result.confidence,
    risk_level: result.risk_level,
    reasons: result.reasons,
    security_tips: result.security_tips,
    recommendation: result.recommendation,
    risk_breakdown: result.risk_breakdown
  };
  return new Promise((resolve, reject) => {
    const request = store.put(entry);
    request.onsuccess = () => {
      cleanupOldEntries().then(resolve).catch((e) => {
        console.warn("[CacheDB] Cleanup failed:", e);
        resolve();
      });
    };
    request.onerror = () => reject(request.error);
  });
}
async function get(url) {
  const store = await getStore("readonly");
  return new Promise((resolve, reject) => {
    const request = store.index("url").get(url);
    request.onsuccess = () => resolve(request.result ?? null);
    request.onerror = () => reject(request.error);
  });
}
async function list(limit = MAX_CACHE_SIZE) {
  const store = await getStore("readonly");
  return new Promise((resolve, reject) => {
    const request = store.index("timestamp").openCursor(null, "prev");
    const results = [];
    request.onsuccess = (event) => {
      const cursor = event.target.result;
      if (!cursor || results.length >= limit) {
        resolve(results);
        return;
      }
      results.push(cursor.value);
      cursor.continue();
    };
    request.onerror = () => reject(request.error);
  });
}
async function clear() {
  const store = await getStore("readwrite");
  return new Promise((resolve, reject) => {
    const request = store.clear();
    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
}
async function isDbReady() {
  try {
    await initDb();
    return true;
  } catch {
    return false;
  }
}
async function cleanupOldEntries() {
  const store = await getStore("readwrite");
  return new Promise((resolve, reject) => {
    const request = store.index("timestamp").openCursor(null, "next");
    let seen = 0;
    request.onsuccess = (event) => {
      const cursor = event.target.result;
      if (!cursor) {
        resolve();
        return;
      }
      seen++;
      if (seen > MAX_CACHE_SIZE) {
        cursor.delete();
      }
      cursor.continue();
    };
    request.onerror = () => reject(request.error);
  });
}
function generateSessionId(url) {
  const random = typeof crypto !== "undefined" && "randomUUID" in crypto ? crypto.randomUUID().slice(0, 12) : Math.random().toString(36).slice(2, 14);
  return `local-${random}-${url.length}`;
}
export {
  BaseApiClient as B,
  DEFAULT_BASE_URL as D,
  ScanApiClient as S,
  clear as c,
  get as g,
  isDbReady as i,
  list as l,
  normalizePrediction as n,
  set as s
};
//# sourceMappingURL=cache.js.map
