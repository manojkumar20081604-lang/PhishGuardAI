function requestBackendAnalysis(url) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({ action: "analyze", url }, (response) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      if (response && response.success && response.data) {
        resolve(response.data);
      } else {
        reject(new Error((response == null ? void 0 : response.error) || "Analysis failed"));
      }
    });
  });
}
function mapScanResult(result) {
  const score = Number(result.risk_score ?? 0);
  const prediction = String(result.prediction ?? "safe").toLowerCase();
  const finalPrediction = prediction === "phishing" ? "Phishing" : prediction === "suspicious" ? "Suspicious" : "Safe";
  const threatLevel = prediction === "phishing" ? "High" : prediction === "suspicious" ? "Medium" : "Low";
  const confidence = Number(result.confidence ?? 0);
  return {
    finalPrediction,
    finalConfidence: confidence > 1 ? Math.round(confidence) : Math.round(confidence * 100),
    finalRiskScore: score,
    finalThreatLevel: threatLevel,
    sources: { local: false, backend: true, threatIntel: false },
    explanation: {
      summary: result.summary || "",
      riskIndicators: Array.isArray(result.reasons) ? result.reasons : [],
      recommendations: Array.isArray(result.security_tips) ? result.security_tips : [],
      breakdown: {
        backendScore: score
      }
    },
    analyzedAt: result.analyzed_at || (/* @__PURE__ */ new Date()).toISOString(),
    isCached: Boolean(result.isCached)
  };
}
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  switch (message.action) {
    case "showAnalysis":
      showAnalysisUI(message.data);
      sendResponse({ success: true });
      break;
    case "showWarning":
      showWarningBanner(message.data);
      sendResponse({ success: true });
      break;
    case "injectUI":
      injectPhishGuardButton(message.data);
      sendResponse({ success: true });
      break;
    case "getPageInfo":
      sendResponse(getPageInfo());
      break;
    case "analyzePage":
      analyzeCurrentPage().then((result) => sendResponse(result));
      return true;
  }
  return true;
});
function getPageInfo() {
  var _a, _b;
  return {
    url: window.location.href,
    title: document.title,
    domain: window.location.hostname,
    forms: getFormsInfo(),
    links: getLinksInfo(),
    scripts: getScriptsInfo(),
    iframes: getIframesInfo(),
    meta: getMetaInfo(),
    textContent: ((_b = (_a = document.body) == null ? void 0 : _a.innerText) == null ? void 0 : _b.substring(0, 5e3)) || ""
  };
}
function getFormsInfo() {
  const forms = Array.from(document.forms);
  return forms.map((form) => ({
    action: form.action,
    method: form.method,
    inputs: Array.from(form.elements).map((el) => ({
      type: el.type,
      name: el.name,
      id: el.id,
      value: el.type === "password" ? "[REDACTED]" : el.value
    }))
  }));
}
function getLinksInfo() {
  const links = Array.from(document.querySelectorAll("a[href]"));
  return links.slice(0, 50).map((link) => {
    var _a;
    return {
      href: link.href,
      text: (_a = link.textContent) == null ? void 0 : _a.trim().substring(0, 100),
      target: link.target,
      rel: link.rel
    };
  });
}
function getScriptsInfo() {
  const scripts = Array.from(document.querySelectorAll("script[src]"));
  return scripts.map((script) => ({
    src: script.src,
    async: script.async,
    defer: script.defer
  }));
}
function getIframesInfo() {
  const iframes = Array.from(document.querySelectorAll("iframe[src]"));
  return iframes.map((iframe) => ({
    src: iframe.src,
    width: iframe.width,
    height: iframe.height
  }));
}
function getMetaInfo() {
  const metas = Array.from(document.querySelectorAll("meta"));
  const info = {};
  metas.forEach((meta) => {
    if (meta.name) info[meta.name] = meta.content;
    const ogProperty = meta.getAttribute("property");
    if (ogProperty) info[ogProperty] = meta.content;
  });
  return info;
}
async function analyzeCurrentPage() {
  const pageInfo = getPageInfo();
  const hasLoginForm = pageInfo.forms.some(
    (form) => form.inputs.some((input) => input.type === "password") || form.inputs.some((input) => /user|email|login|signin/i.test(input.name || ""))
  );
  try {
    const backendResult = mapScanResult(await requestBackendAnalysis(pageInfo.url));
    const combinedReasons = [
      ...backendResult.explanation.riskIndicators,
      ...hasLoginForm ? ["Login form detected on page"] : []
    ];
    if (hasLoginForm && !combinedReasons.includes("Login form detected on page")) {
      combinedReasons.push("Login form detected on page");
    }
    return {
      ...backendResult,
      explanation: {
        ...backendResult.explanation,
        riskIndicators: combinedReasons,
        recommendations: hasLoginForm && backendResult.finalThreatLevel !== "Low" ? ["DO NOT enter credentials on this page", ...backendResult.explanation.recommendations] : backendResult.explanation.recommendations
      },
      pageInfo: {
        hasLoginForm,
        formsCount: pageInfo.forms.length,
        linksCount: pageInfo.links.length,
        scriptsCount: pageInfo.scripts.length,
        iframesCount: pageInfo.iframes.length
      }
    };
  } catch (error) {
    return {
      finalPrediction: "Unknown",
      finalConfidence: 0,
      finalRiskScore: 0,
      finalThreatLevel: "Unknown",
      sources: { local: true, backend: false, threatIntel: false },
      explanation: {
        summary: "Backend unavailable - only basic page checks were performed.",
        riskIndicators: [
          ...hasLoginForm ? ["Login form detected on page"] : []
        ],
        recommendations: [
          "Verify the site authenticity before entering sensitive data"
        ],
        breakdown: {}
      },
      analyzedAt: (/* @__PURE__ */ new Date()).toISOString(),
      error: error instanceof Error ? error.message : String(error),
      pageInfo: {
        hasLoginForm,
        formsCount: pageInfo.forms.length,
        linksCount: pageInfo.links.length,
        scriptsCount: pageInfo.scripts.length,
        iframesCount: pageInfo.iframes.length
      }
    };
  }
}
function injectPhishGuardButton(data) {
  if (document.getElementById("phishguard-float-btn")) return;
  const btn = document.createElement("div");
  btn.id = "phishguard-float-btn";
  btn.innerHTML = `
    <style>
      #phishguard-float-btn {
        position: fixed;
        bottom: 20px;
        right: 20px;
        width: 56px;
        height: 56px;
        border-radius: 28px;
        background: linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%);
        box-shadow: 0 4px 20px rgba(30, 58, 138, 0.4);
        cursor: pointer;
        z-index: 2147483647;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: transform 0.2s, box-shadow 0.2s;
        border: none;
      }
      #phishguard-float-btn:hover {
        transform: scale(1.1);
        box-shadow: 0 6px 28px rgba(30, 58, 138, 0.5);
      }
      #phishguard-float-btn.phishguard-safe { background: linear-gradient(135deg, #065f46 0%, #10b981 100%); }
      #phishguard-float-btn.phishguard-suspicious { background: linear-gradient(135deg, #92400e 0%, #f59e0b 100%); }
      #phishguard-float-btn.phishguard-phishing { background: linear-gradient(135deg, #991b1b 0%, #ef4444 100%); animation: phishguard-pulse 2s infinite; }
      @keyframes phishguard-pulse { 0%, 100% { box-shadow: 0 4px 20px rgba(239, 68, 68, 0.4); } 50% { box-shadow: 0 4px 30px rgba(239, 68, 68, 0.7); } }
      #phishguard-float-btn svg { width: 28px; height: 28px; color: white; }
      #phishguard-tooltip {
        position: absolute;
        bottom: 70px;
        right: 0;
        background: #1e293b;
        color: white;
        padding: 8px 12px;
        border-radius: 6px;
        font-size: 12px;
        white-space: nowrap;
        opacity: 0;
        visibility: hidden;
        transition: opacity 0.2s, visibility 0.2s;
        pointer-events: none;
      }
      #phishguard-float-btn:hover #phishguard-tooltip {
        opacity: 1;
        visibility: visible;
      }
    </style>
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path>
      <path d="M9 12l2 2 4-4"></path>
    </svg>
    <div id="phishguard-tooltip">PhishGuard AI - Click to analyze</div>
  `;
  if (data) {
    updateButtonState(btn, data.finalThreatLevel);
  } else {
    updateButtonState(btn, "Low");
    requestBackendAnalysis(window.location.href).then((result) => {
      if (document.getElementById("phishguard-float-btn")) {
        updateButtonState(btn, mapScanResult(result).finalThreatLevel);
      }
    }).catch(() => {
    });
  }
  btn.addEventListener("click", () => {
    chrome.runtime.sendMessage({ action: "analyze", url: window.location.href }, (response) => {
      if (chrome.runtime.lastError || !response || !response.success) return;
      showAnalysisUI(response.data);
      updateButtonState(btn, response.data.finalThreatLevel);
    });
  });
  document.body.appendChild(btn);
}
function updateButtonState(btn, threatLevel) {
  btn.className = "phishguard-float-btn";
  switch (threatLevel) {
    case "High":
      btn.classList.add("phishguard-phishing");
      btn.querySelector("#phishguard-tooltip").textContent = "⚠ Phishing detected - Click for details";
      break;
    case "Medium":
      btn.classList.add("phishguard-suspicious");
      btn.querySelector("#phishguard-tooltip").textContent = "⚠ Suspicious - Click for details";
      break;
    case "Low":
    default:
      btn.classList.add("phishguard-safe");
      btn.querySelector("#phishguard-tooltip").textContent = "✓ Safe - Click to re-analyze";
      break;
  }
}
function showAnalysisUI(result) {
  var _a;
  const existing = document.getElementById("phishguard-modal");
  if (existing) existing.remove();
  const modal = document.createElement("div");
  modal.id = "phishguard-modal";
  modal.innerHTML = `
    <style>
      #phishguard-modal-overlay {
        position: fixed;
        top: 0; left: 0; right: 0; bottom: 0;
        background: rgba(0, 0, 0, 0.7);
        z-index: 2147483646;
        display: flex;
        align-items: center;
        justify-content: center;
        animation: phishguard-fade-in 0.2s ease;
      }
      @keyframes phishguard-fade-in { from { opacity: 0; } to { opacity: 1; } }
      #phishguard-modal {
        background: #1e293b;
        border-radius: 16px;
        padding: 0;
        max-width: 520px;
        width: 90%;
        max-height: 85vh;
        overflow: hidden;
        box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
        border: 1px solid #334155;
        animation: phishguard-slide-up 0.3s ease;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      }
      @keyframes phishguard-slide-up { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
      .phishguard-header {
        padding: 20px 24px;
        border-bottom: 1px solid #334155;
        display: flex;
        align-items: center;
        justify-content: space-between;
      }
      .phishguard-header h2 { margin: 0; font-size: 18px; font-weight: 600; color: #f1f5f9; }
      .phishguard-badge {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 6px 14px;
        border-radius: 20px;
        font-size: 13px;
        font-weight: 600;
      }
      .phishguard-badge.phishing { background: rgba(239, 68, 68, 0.2); color: #ef4444; }
      .phishguard-badge.suspicious { background: rgba(245, 158, 11, 0.2); color: #f59e0b; }
      .phishguard-badge.safe { background: rgba(16, 185, 129, 0.2); color: #10b981; }
      .phishguard-close {
        background: none;
        border: none;
        color: #94a3b8;
        cursor: pointer;
        padding: 8px;
        border-radius: 8px;
        transition: background 0.2s, color 0.2s;
      }
      .phishguard-close:hover { background: #334155; color: #f1f5f9; }
      .phishguard-content { padding: 24px; overflow-y: auto; max-height: 60vh; }
      .phishguard-section { margin-bottom: 24px; }
      .phishguard-section:last-child { margin-bottom: 0; }
      .phishguard-section-title { font-size: 14px; font-weight: 600; color: #94a3b8; text-transform: uppercase; letter-spacing: 0.05em; margin-bottom: 12px; }
      .phishguard-score { display: flex; align-items: center; gap: 16px; }
      .phishguard-score-circle {
        width: 80px;
        height: 80px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        position: relative;
      }
      .phishguard-score-circle svg { width: 80px; height: 80px; transform: rotate(-90deg); }
      .phishguard-score-circle circle { fill: none; stroke-width: 6; }
      .phishguard-score-circle .bg { stroke: #334155; }
      .phishguard-score-circle .progress { stroke-linecap: round; transition: stroke-dashoffset 0.5s ease; }
      .phishguard-score-value { position: absolute; font-size: 24px; font-weight: 700; color: #f1f5f9; }
      .phishguard-score-label { color: #94a3b8; font-size: 14px; }
      .phishguard-reasons { list-style: none; padding: 0; margin: 0; }
      .phishguard-reasons li { display: flex; align-items: flex-start; gap: 10px; padding: 10px 12px; background: #0f172a; border-radius: 8px; margin-bottom: 8px; color: #e2e8f0; font-size: 14px; line-height: 1.5; }
      .phishguard-reasons li:last-child { margin-bottom: 0; }
      .phishguard-reasons .icon { flex-shrink: 0; width: 20px; height: 20px; color: currentColor; }
      .phishguard-recommendations { display: flex; flex-direction: column; gap: 10px; }
      .phishguard-recommendation { display: flex; align-items: flex-start; gap: 10px; padding: 12px; background: #0f172a; border-radius: 8px; color: #e2e8f0; font-size: 14px; line-height: 1.5; border-left: 3px solid; }
      .phishguard-recommendation.high { border-left-color: #ef4444; }
      .phishguard-recommendation.medium { border-left-color: #f59e0b; }
      .phishguard-recommendation.low { border-left-color: #10b981; }
      .phishguard-breakdown { display: grid; grid-template-columns: repeat(2, 1fr); gap: 12px; }
      .phishguard-breakdown-item { background: #0f172a; padding: 14px; border-radius: 8px; }
      .phishguard-breakdown-label { font-size: 12px; color: #94a3b8; margin-bottom: 4px; }
      .phishguard-breakdown-value { font-size: 20px; font-weight: 700; color: #f1f5f9; }
      .phishguard-actions { display: flex; gap: 10px; padding-top: 16px; border-top: 1px solid #334155; }
      .phishguard-btn { flex: 1; padding: 12px 16px; border-radius: 8px; font-size: 14px; font-weight: 600; cursor: pointer; border: none; transition: opacity 0.2s; }
      .phishguard-btn:hover { opacity: 0.9; }
      .phishguard-btn-primary { background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%); color: white; }
      .phishguard-btn-secondary { background: #334155; color: #e2e8f0; }
    </style>
    <div id="phishguard-modal-overlay">
      <div id="phishguard-modal">
        <div class="phishguard-header">
          <h2>PhishGuard AI Analysis</h2>
          <span class="phishguard-badge ${result.finalPrediction.toLowerCase()}">
            ${getBadgeIcon(result.finalPrediction)} ${result.finalPrediction}
          </span>
        </div>
        <div class="phishguard-content">
          <div class="phishguard-section">
            <div class="phishguard-section-title">Risk Score</div>
            <div class="phishguard-score">
              <div class="phishguard-score-circle">
                <svg viewBox="0 0 80 80">
                  <circle class="bg" cx="40" cy="40" r="34"></circle>
                  <circle class="progress ${getProgressClass(result.finalThreatLevel)}" 
                    cx="40" cy="40" r="34"
                    stroke-dasharray="213.6"
                    stroke-dashoffset="${getProgressOffset(result.finalRiskScore)}">
                  </circle>
                </svg>
                <span class="phishguard-score-value">${result.finalRiskScore}</span>
              </div>
              <div>
                <div class="phishguard-score-label">Threat Level: <strong style="color: ${getThreatColor(result.finalThreatLevel)}">${result.finalThreatLevel}</strong></div>
                <div class="phishguard-score-label">Confidence: <strong>${result.finalConfidence}%</strong></div>
                <div class="phishguard-score-label">Sources: ${getSourcesText(result.sources)}</div>
              </div>
            </div>
          </div>
          
          ${result.explanation.riskIndicators && result.explanation.riskIndicators.length > 0 ? `
          <div class="phishguard-section">
            <div class="phishguard-section-title">Risk Indicators</div>
            <ul class="phishguard-reasons">
              ${result.explanation.riskIndicators.map((reason) => `
                <li>
                  <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <circle cx="12" cy="12" r="10"></circle>
                    <line x1="12" y1="8" x2="12" y2="12"></line>
                    <line x1="12" y1="16" x2="12.01" y2="16"></line>
                  </svg>
                  ${reason}
                </li>
              `).join("")}
            </ul>
          </div>
          ` : ""}
          
          <div class="phishguard-section">
            <div class="phishguard-section-title">Recommendations</div>
            <div class="phishguard-recommendations">
              ${((_a = result.explanation.recommendations) == null ? void 0 : _a.map((rec, i) => `
                <div class="phishguard-recommendation ${result.finalThreatLevel.toLowerCase()}">
                  <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <polyline points="9 18 15 12 9 6"></polyline>
                  </svg>
                  ${rec}
                </div>
              `).join("")) || ""}
            </div>
          </div>
          
          ${result.explanation.breakdown ? `
          <div class="phishguard-section">
            <div class="phishguard-section-title">Score Breakdown</div>
            <div class="phishguard-breakdown">
              ${result.explanation.breakdown.localScore !== void 0 ? `
              <div class="phishguard-breakdown-item">
                <div class="phishguard-breakdown-label">Local Analysis</div>
                <div class="phishguard-breakdown-value">${result.explanation.breakdown.localScore}</div>
              </div>
              ` : ""}
              ${result.explanation.breakdown.backendScore !== void 0 ? `
              <div class="phishguard-breakdown-item">
                <div class="phishguard-breakdown-label">Backend ML</div>
                <div class="phishguard-breakdown-value">${result.explanation.breakdown.backendScore}</div>
              </div>
              ` : ""}
              ${result.explanation.breakdown.threatIntelScore !== void 0 ? `
              <div class="phishguard-breakdown-item">
                <div class="phishguard-breakdown-label">Threat Intel</div>
                <div class="phishguard-breakdown-value">${result.explanation.breakdown.threatIntelScore}</div>
              </div>
              ` : ""}
              <div class="phishguard-breakdown-item">
                <div class="phishguard-breakdown-label">Final Score</div>
                <div class="phishguard-breakdown-value">${result.finalRiskScore}</div>
              </div>
            </div>
          </div>
          ` : ""}
          
          <div class="phishguard-actions">
            <button class="phishguard-btn phishguard-btn-secondary" id="phishguard-close-modal">Close</button>
            <button class="phishguard-btn phishguard-btn-primary" id="phishguard-report">Report False Positive</button>
          </div>
        </div>
      </div>
    </div>
  `;
  document.body.appendChild(modal);
  modal.querySelector("#phishguard-close-modal").addEventListener("click", () => modal.remove());
  modal.querySelector("#phishguard-modal-overlay").addEventListener("click", (e) => {
    if (e.target === modal.querySelector("#phishguard-modal-overlay")) modal.remove();
  });
  modal.querySelector("#phishguard-report").addEventListener("click", () => {
    chrome.runtime.sendMessage({
      action: "reportFeedback",
      data: { url: window.location.href, prediction: result.finalPrediction, correct: false }
    });
    alert("Thank you for reporting! This helps improve PhishGuard AI.");
    modal.remove();
  });
  const handleEsc = (e) => {
    if (e.key === "Escape") {
      modal.remove();
      document.removeEventListener("keydown", handleEsc);
    }
  };
  document.addEventListener("keydown", handleEsc);
}
function showWarningBanner(data) {
  const existing = document.getElementById("phishguard-warning-banner");
  if (existing) existing.remove();
  const banner = document.createElement("div");
  banner.id = "phishguard-warning-banner";
  banner.innerHTML = `
    <style>
      #phishguard-warning-banner {
        position: fixed;
        top: 0; left: 0; right: 0;
        z-index: 2147483647;
        padding: 14px 20px;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        font-size: 14px;
        line-height: 1.5;
        animation: phishguard-slide-down 0.3s ease;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
      }
      @keyframes phishguard-slide-down { from { transform: translateY(-100%); } to { transform: translateY(0); } }
      #phishguard-warning-banner.phishing { background: linear-gradient(135deg, #991b1b 0%, #ef4444 100%); color: white; }
      #phishguard-warning-banner.suspicious { background: linear-gradient(135deg, #92400e 0%, #f59e0b 100%); color: white; }
      .phishguard-banner-content { max-width: 1200px; margin: 0 auto; display: flex; align-items: center; justify-content: space-between; gap: 16px; flex-wrap: wrap; }
      .phishguard-banner-text { display: flex; align-items: center; gap: 12px; flex: 1; min-width: 280px; }
      .phishguard-banner-icon { width: 24px; height: 24px; flex-shrink: 0; }
      .phishguard-banner-actions { display: flex; gap: 8px; flex-shrink: 0; }
      .phishguard-banner-btn { padding: 8px 16px; border-radius: 6px; font-size: 13px; font-weight: 600; cursor: pointer; border: none; transition: opacity 0.2s; }
      .phishguard-banner-btn:hover { opacity: 0.9; }
      .phishguard-banner-btn-primary { background: white; color: #991b1b; }
      .phishguard-banner-btn-secondary { background: rgba(255,255,255,0.2); color: white; border: 1px solid rgba(255,255,255,0.3); }
      .phishguard-banner-btn-suspicious-primary { background: white; color: #92400e; }
      .phishguard-banner-btn-suspicious-secondary { background: rgba(255,255,255,0.2); color: white; border: 1px solid rgba(255,255,255,0.3); }
    </style>
    <div class="phishguard-banner-content">
      <div class="phishguard-banner-text">
        <svg class="phishguard-banner-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path>
          <line x1="12" y1="9" x2="12" y2="13"></line>
          <line x1="12" y1="17" x2="12.01" y2="17"></line>
        </svg>
        <span><strong>PhishGuard AI:</strong> This page is <strong>${data.prediction}</strong> (${data.level} risk). ${data.message}</span>
      </div>
      <div class="phishguard-banner-actions">
        <button class="phishguard-banner-btn phishguard-banner-btn-${data.level.toLowerCase()}-primary" id="phishguard-banner-analyze">View Details</button>
        <button class="phishguard-banner-btn phishguard-banner-btn-${data.level.toLowerCase()}-secondary" id="phishguard-banner-dismiss">Dismiss</button>
      </div>
    </div>
  `;
  const predLower = String(data.prediction ?? "").toLowerCase();
  const levelLower = String(data.level ?? "").toLowerCase();
  const tone = predLower.includes("phish") || levelLower === "high" ? "phishing" : "suspicious";
  banner.className = tone;
  document.body.insertBefore(banner, document.body.firstChild);
  document.body.style.paddingTop = banner.offsetHeight + "px";
  const btnBase = tone === "phishing" ? "" : "-suspicious";
  const analyzeBtn = banner.querySelector("#phishguard-banner-analyze");
  analyzeBtn.className = `phishguard-banner-btn phishguard-banner-btn${btnBase}-primary`;
  const dismissBtn = banner.querySelector("#phishguard-banner-dismiss");
  dismissBtn.className = `phishguard-banner-btn phishguard-banner-btn${btnBase}-secondary`;
  analyzeBtn.addEventListener("click", () => {
    chrome.runtime.sendMessage({ action: "analyze", url: window.location.href }, (response) => {
      if (chrome.runtime.lastError || !response || !response.success) return;
      showAnalysisUI(response.data);
    });
    markDismissedThisVisit();
    banner.remove();
    document.body.style.paddingTop = "";
  });
  dismissBtn.addEventListener("click", () => {
    markDismissedThisVisit();
    banner.remove();
    document.body.style.paddingTop = "";
  });
}
const PROTECT_DEFAULTS = {
  autoProtectLevel: "suspicious",
  blockHighRiskPages: true
};
async function getProtectSettings() {
  try {
    const stored = await chrome.storage.local.get("phishguard_settings");
    return { ...PROTECT_DEFAULTS, ...stored.phishguard_settings ?? {} };
  } catch {
    return { ...PROTECT_DEFAULTS };
  }
}
function markDismissedThisVisit() {
  try {
    sessionStorage.setItem(`pgai-dismissed:${window.location.href}`, "1");
  } catch {
  }
}
function isDismissedThisVisit() {
  try {
    return sessionStorage.getItem(`pgai-dismissed:${window.location.href}`) === "1";
  } catch {
    return false;
  }
}
async function runAutoProtect() {
  const settings = await getProtectSettings();
  chrome.storage.local.get("phishguard_settings", (result) => {
    const s = result.phishguard_settings || {};
    if (s.showBadge !== false && s.autoAnalyze !== false && !document.getElementById("phishguard-float-btn")) {
      injectPhishGuardButton();
    }
  });
  if (settings.autoProtectLevel === "off") return;
  if (!/^https?:/i.test(window.location.href)) return;
  try {
    const raw = await requestBackendAnalysis(window.location.href);
    applyAutoProtectVerdict(mapScanResult(raw), settings);
  } catch {
  }
}
function applyAutoProtectVerdict(ui, settings) {
  armPasswordAlarm(ui);
  if (isDismissedThisVisit()) return;
  if (ui.finalPrediction === "Phishing") {
    showWarningBanner({
      prediction: "PHISHING",
      level: "HIGH",
      message: ui.explanation.summary || "Strong phishing indicators detected on this page."
    });
    if (settings.blockHighRiskPages && ui.finalRiskScore >= 85) {
      showBlockPage(ui);
    }
  } else if (ui.finalPrediction === "Suspicious") {
    showSuspiciousChip(ui);
  }
}
function showBlockPage(ui) {
  if (document.getElementById("pgai-block-page")) return;
  const reasons = (ui.explanation.riskIndicators ?? []).slice(0, 4);
  const overlay = document.createElement("div");
  overlay.id = "pgai-block-page";
  overlay.innerHTML = `
    <style>
      #pgai-block-page {
        position: fixed; inset: 0; z-index: 2147483647;
        background: rgba(5, 8, 20, 0.96);
        display: flex; align-items: center; justify-content: center;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      }
      #pgai-block-card {
        max-width: 520px; width: 90%;
        background: #161b2e; border: 1px solid #ef4444;
        border-radius: 16px; padding: 32px; color: #f1f5f9;
        box-shadow: 0 25px 60px rgba(239, 68, 68, 0.25);
      }
      #pgai-block-card h1 { margin: 0 0 6px; font-size: 22px; color: #ef4444; }
      #pgai-block-url { color: #94a3b8; font-size: 13px; word-break: break-all; margin-bottom: 16px; }
      .pgai-block-reasons { margin: 0 0 20px; padding-left: 18px; color: #e2e8f0; font-size: 14px; line-height: 1.7; }
      .pgai-block-actions { display: flex; gap: 12px; align-items: center; }
      #pgai-go-back {
        flex: 1; padding: 12px 18px; border: none; border-radius: 10px;
        background: linear-gradient(135deg, #3b82f6, #2563eb);
        color: white; font-size: 15px; font-weight: 700; cursor: pointer;
      }
      #pgai-continue {
        background: none; border: none; color: #64748b; font-size: 13px;
        cursor: pointer; text-decoration: underline;
      }
    </style>
    <div id="pgai-block-card">
      <h1>&#9940; Dangerous page blocked</h1>
      <div id="pgai-block-url">${escapeHtmlAttr(window.location.href)}</div>
      <ul class="pgai-block-reasons">
        ${reasons.map((r) => `<li>${escapeHtmlAttr(String(r))}</li>`).join("")}
        <li><strong>Risk score: ${ui.finalRiskScore}/100</strong></li>
      </ul>
      <div class="pgai-block-actions">
        <button id="pgai-go-back">Go back to safety</button>
        <button id="pgai-continue">Continue anyway</button>
      </div>
    </div>
  `;
  document.documentElement.appendChild(overlay);
  overlay.querySelector("#pgai-go-back").addEventListener("click", () => {
    markDismissedThisVisit();
    if (history.length > 1) {
      history.back();
    } else {
      window.location.href = "about:blank";
    }
  });
  overlay.querySelector("#pgai-continue").addEventListener("click", () => {
    markDismissedThisVisit();
    overlay.remove();
  });
}
function showSuspiciousChip(ui) {
  if (document.getElementById("pgai-suspicious-chip")) return;
  const chip = document.createElement("div");
  chip.id = "pgai-suspicious-chip";
  chip.innerHTML = `
    <style>
      #pgai-suspicious-chip {
        position: fixed; bottom: 84px; left: 20px; z-index: 2147483646;
        padding: 8px 14px; border-radius: 999px; cursor: pointer;
        background: rgba(146, 64, 14, 0.95); color: #fff;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        font-size: 12.5px; font-weight: 600;
        box-shadow: 0 4px 14px rgba(0,0,0,0.35);
        transition: transform .15s ease;
      }
      #pgai-suspicious-chip:hover { transform: translateY(-2px); }
    </style>
    &#9888; Suspicious &middot; score ${ui.finalRiskScore}
  `;
  chip.addEventListener("click", () => {
    showAnalysisUI(ui);
    chip.remove();
  });
  document.body.appendChild(chip);
}
let pwAlarmUi = null;
let pwAlarmInput = null;
let pwNotified = false;
let pwRafPending = false;
function armPasswordAlarm(ui) {
  const pred = String((ui == null ? void 0 : ui.finalPrediction) ?? "").toLowerCase();
  if (pred !== "phishing" && pred !== "suspicious") return;
  pwAlarmUi = ui;
  if (isPwDismissed()) return;
  const existingField = document.querySelector('input[type="password"]');
  if (existingField) showPasswordAlarm(existingField);
  document.addEventListener("focusin", onPasswordFocus, true);
  window.addEventListener("scroll", positionPasswordAlarm, { passive: true });
  window.addEventListener("resize", positionPasswordAlarm, { passive: true });
}
function onPasswordFocus(event) {
  const el = event.target;
  if (!el || el.type !== "password") return;
  showPasswordAlarm(el);
}
function isPwDismissed() {
  try {
    return sessionStorage.getItem("pgai-pw-dismissed") === "1";
  } catch {
    return false;
  }
}
function dismissPasswordAlarm() {
  var _a;
  try {
    sessionStorage.setItem("pgai-pw-dismissed", "1");
  } catch {
  }
  (_a = document.getElementById("pgai-pw-alarm")) == null ? void 0 : _a.remove();
  pwAlarmInput = null;
}
function showPasswordAlarm(input) {
  if (isPwDismissed()) return;
  if (!document.documentElement.contains(input)) return;
  pwAlarmInput = input;
  let alarm = document.getElementById("pgai-pw-alarm");
  if (!alarm) {
    alarm = document.createElement("div");
    alarm.id = "pgai-pw-alarm";
    document.body.appendChild(alarm);
  }
  const danger = String((pwAlarmUi == null ? void 0 : pwAlarmUi.finalPrediction) ?? "").toLowerCase() === "phishing";
  alarm.className = danger ? "danger" : "warn";
  alarm.innerHTML = `
    <style>
      #pgai-pw-alarm {
        position: fixed; left: -9999px; top: -9999px; z-index: 2147483647;
        max-width: min(420px, calc(100vw - 24px));
        padding: 12px 16px; border-radius: 10px; color: #fff;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        font-size: 13px; line-height: 1.45;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.35);
        animation: pgai-pw-in 0.18s ease;
      }
      @keyframes pgai-pw-in { from { opacity: 0; transform: translateY(-6px); } to { opacity: 1; transform: translateY(0); } }
      #pgai-pw-alarm.danger { background: linear-gradient(135deg, #991b1b, #ef4444); border: 1px solid #fca5a5; }
      #pgai-pw-alarm.warn { background: linear-gradient(135deg, #92400e, #f59e0b); border: 1px solid #fde68a; }
      .pgai-pw-row { display: flex; align-items: flex-start; gap: 10px; }
      .pgai-pw-icon { width: 20px; height: 20px; flex-shrink: 0; margin-top: 1px; }
      .pgai-pw-text strong { display: block; font-size: 13.5px; margin-bottom: 2px; }
      .pgai-pw-actions { display: flex; gap: 8px; margin-top: 10px; }
      .pgai-pw-btn { padding: 6px 12px; border-radius: 6px; font-size: 12px; font-weight: 700; cursor: pointer; border: none; }
      #pgai-pw-details { background: rgba(255, 255, 255, 0.22); color: #fff; }
      #pgai-pw-dismiss { background: #fff; color: #7f1d1d; }
      #pgai-pw-alarm.warn #pgai-pw-dismiss { color: #78350f; }
    </style>
    <div class="pgai-pw-row">
      <svg class="pgai-pw-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path>
        <line x1="12" y1="9" x2="12" y2="13"></line>
        <line x1="12" y1="17" x2="12.01" y2="17"></line>
      </svg>
      <div class="pgai-pw-text">
        <strong>${danger ? "&#9940; Do NOT enter your password" : "&#9888; Avoid entering your password"}</strong>
        PhishGuard flagged this page (${escapeHtmlAttr(window.location.hostname)}) as
        <strong>${danger ? "PHISHING" : "SUSPICIOUS"}</strong>.
      </div>
    </div>
    <div class="pgai-pw-actions">
      <button class="pgai-pw-btn" id="pgai-pw-details">View details</button>
      <button class="pgai-pw-btn" id="pgai-pw-dismiss">Dismiss</button>
    </div>
  `;
  alarm.querySelector("#pgai-pw-dismiss").addEventListener("click", dismissPasswordAlarm);
  alarm.querySelector("#pgai-pw-details").addEventListener("click", () => {
    if (pwAlarmUi) showAnalysisUI(pwAlarmUi);
  });
  notifyPasswordAlarmOnce();
  positionPasswordAlarm();
}
function positionPasswordAlarm() {
  const alarm = document.getElementById("pgai-pw-alarm");
  if (!alarm) return;
  if (!pwAlarmInput || !document.documentElement.contains(pwAlarmInput)) {
    pwAlarmInput = null;
    alarm.remove();
    return;
  }
  if (pwRafPending) return;
  pwRafPending = true;
  requestAnimationFrame(() => {
    pwRafPending = false;
    const a = document.getElementById("pgai-pw-alarm");
    if (!a) return;
    if (!pwAlarmInput || !document.documentElement.contains(pwAlarmInput)) {
      pwAlarmInput = null;
      a.remove();
      return;
    }
    const rect = pwAlarmInput.getBoundingClientRect();
    const left = Math.max(12, Math.min(rect.left, window.innerWidth - a.offsetWidth - 12));
    const above = rect.top - a.offsetHeight - 10;
    a.style.left = `${left}px`;
    a.style.top = `${above >= 12 ? above : Math.min(rect.bottom + 10, window.innerHeight - a.offsetHeight - 12)}px`;
  });
}
function notifyPasswordAlarmOnce() {
  if (pwNotified) return;
  pwNotified = true;
  try {
    chrome.runtime.sendMessage(
      { action: "notifyPasswordAlarm", data: { url: window.location.href } },
      () => void chrome.runtime.lastError
    );
  } catch {
  }
}
function escapeHtmlAttr(text) {
  return text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
function getBadgeIcon(prediction) {
  switch (prediction) {
    case "Phishing":
      return "🔴";
    case "Suspicious":
      return "🟠";
    case "Safe":
      return "🟢";
    default:
      return "⚪";
  }
}
function getProgressClass(threatLevel) {
  switch (threatLevel) {
    case "High":
      return "phishing";
    case "Medium":
      return "suspicious";
    case "Low":
      return "safe";
    default:
      return "safe";
  }
}
function getProgressOffset(score) {
  const circumference = 2 * Math.PI * 34;
  return circumference * (1 - score / 100);
}
function getThreatColor(threatLevel) {
  switch (threatLevel) {
    case "High":
      return "#ef4444";
    case "Medium":
      return "#f59e0b";
    case "Low":
      return "#10b981";
    default:
      return "#64748b";
  }
}
function getSourcesText(sources) {
  const parts = [];
  if (sources.local) parts.push("Local");
  if (sources.backend) parts.push("Backend ML");
  if (sources.threatIntel) parts.push("Threat Intel");
  return parts.join(" + ") || "Local";
}
void runAutoProtect();
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && changes.phishguard_settings) {
    const settings = changes.phishguard_settings.newValue;
    const btn = document.getElementById("phishguard-float-btn");
    if (settings.showBadge === false && btn) {
      btn.remove();
    } else if (settings.showBadge !== false && !btn && settings.autoAnalyze !== false) {
      injectPhishGuardButton();
    }
    void runAutoProtect();
  }
});
console.log("[ContentScript] PhishGuard AI content script loaded");
//# sourceMappingURL=content.js.map
