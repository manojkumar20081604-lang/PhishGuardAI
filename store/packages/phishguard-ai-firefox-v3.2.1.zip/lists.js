import { B as BaseApiClient } from "./cache.js";
class MetricsApiClient extends BaseApiClient {
  constructor(baseUrl) {
    super(baseUrl);
  }
  /**
   * Get dashboard overview metrics
   */
  async getOverview() {
    console.log("[MetricsAPI] Fetching overview metrics");
    return this.requestWithRetry(
      "/api/v1/metrics/overview",
      { method: "GET" }
    );
  }
  /**
   * Check system health (backend availability, response time)
   */
  async getSystemHealth() {
    console.log("[MetricsAPI] Checking system health");
    return this.requestWithRetry(
      "/api/v1/metrics/system/health",
      { method: "GET" }
    );
  }
  /**
   * Quick health check (boolean) - for lightweight availability checks
   */
  async isBackendAvailable() {
    try {
      await this.requestWithRetry("/api/v1/metrics/system/health", { method: "GET" }, { maxRetries: 0 });
      return true;
    } catch {
      return false;
    }
  }
}
const TRUST_KEY = "pgai_trust_lists";
async function getLists() {
  try {
    const stored = await chrome.storage.local.get(TRUST_KEY);
    const lists = stored[TRUST_KEY];
    return {
      trusted: Array.isArray(lists == null ? void 0 : lists.trusted) ? lists.trusted : [],
      blocked: Array.isArray(lists == null ? void 0 : lists.blocked) ? lists.blocked : []
    };
  } catch {
    return { trusted: [], blocked: [] };
  }
}
async function saveLists(lists) {
  await chrome.storage.local.set({ [TRUST_KEY]: lists });
}
async function addTo(list, rawDomain) {
  const domain = normalizeDomain(rawDomain);
  if (!domain) throw new Error("Invalid domain");
  const lists = await getLists();
  if (!lists[list].includes(domain)) {
    lists[list].push(domain);
    lists[list].sort();
    await saveLists(lists);
  }
  return lists;
}
async function removeFrom(list, rawDomain) {
  const domain = normalizeDomain(rawDomain);
  const lists = await getLists();
  lists[list] = lists[list].filter((d) => d !== domain);
  await saveLists(lists);
  return lists;
}
function normalizeDomain(input) {
  let value = (input || "").trim().toLowerCase();
  if (!value) return "";
  if (/^[a-z][a-z0-9+.-]*:\/\//.test(value)) {
    try {
      value = new URL(value).hostname;
    } catch {
      return "";
    }
  }
  value = value.split("/")[0].split("?")[0].split(":").pop() ?? "";
  if (!/^[a-z0-9.-]+\.[a-z]{2,}$/.test(value)) return "";
  return value;
}
function hostMatches(host, entry) {
  return host === entry || host.endsWith(`.${entry}`);
}
function hostnameOf(url) {
  const normalized = normalizeDomain(url);
  return normalized;
}
async function checkTrust(url) {
  const host = hostnameOf(url);
  if (!host) return "unlisted";
  const lists = await getLists();
  if (lists.blocked.some((d) => hostMatches(host, d))) return "blocked";
  if (lists.trusted.some((d) => hostMatches(host, d))) return "trusted";
  return "unlisted";
}
export {
  MetricsApiClient as M,
  addTo as a,
  checkTrust as c,
  getLists as g,
  normalizeDomain as n,
  removeFrom as r
};
//# sourceMappingURL=lists.js.map
